
## 剔除相关性较高变量 jxl_call_num_aver_6months, jxl_contact1_rank, apt_ec_overduephasetotallastyear
#删除 apt_facetrial_creditcardfalg_2 


'''
# 最终模型
'''

columns = ['yx_otherorgan_times',
'jxl_id_comb_othertel_num',
'jxl_tel_length',
'jxl_black_dir_cont_num',
'apt_ec_overduedaystotallastyear',
'vehicle_minput_chargetimes',
'apt_ec_historyloantimes',
'apt_age',
'yx_underly_record_num',
'jxl_tel_loan_call_sumnum',
'jxl_turnoff_length',
'jxl_contact2_times',
'jxl_black_interme_score',
'apt_currentaddrresideyears',
'vehicle_evtrpt_mileage',
'apt_telecom_phoneuserduration',
'jxl_contact1_times',
'apt_comp_monthlysalary',
'vehicle_evtrpt_evalprice_trend',
'td_dishonest_list_check_NaN',
'vehicle_minput_lastmortgagerinfo_1',
'apt_facetrial_housetype_1',
'vehicle_minput_ownerway_1n2',
'vehicle_minput_registcertflag_1',
'vehicle_minput_obtaindate',
'vehicle_minput_lastreleasedate',
'apt_ec_lastloansettleddate']
print(len(columns))
clf = GradientBoostingClassifier(learning_rate=0.05, 
                                     min_samples_leaf=21, 
                                     max_depth=6, 
                                     max_leaf_nodes=20, 
                                     n_estimators=20,
                                     random_state=0) 
clf.fit(x_train[columns], y_train)     
a = clf.feature_importances_.tolist()
pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
fpr, tpr, th = roc_curve(ori_y_train, pred_p)
ks = tpr - fpr
pred_p2 = clf.predict_proba(x_test[columns])[:,1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr

feature_importance = pd.DataFrame({'var_name':columns, 'importance':a}).sort_values('importance', ascending=False)
feature_importance = pd.merge(feature_importance, dict_desc[['var_name', 'var_desc']], on='var_name', how='left')[['var_name', 'var_desc', 'importance']]
print(feature_importance)
print('train ks: ' + str(max(ks)))
print('test ks:  ' + str(max(ks2)))

pickle.dump(clf, open('../部署/gbdt2_v2.pkl', 'wb'))
feature_importance.to_excel('../performance/feature_importance_v2.xlsx')

'''
## 模型表现 
'''

pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
min_scores = r_p_chart(ori_y_train, pred_p, part=20)
min_scores = [round(i, 5) for i in min_scores]
min_scores[19] = 0
cuts = [round(min_scores[i]*100.0, 3) for i in range(20)[::-1]] + [100.0]

print('训练集')
pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
fpr, tpr, th = roc_curve(ori_y_train, pred_p)
ks = tpr - fpr
print('train ks: ' + str(max(ks)))
r_p_chart2(ori_y_train, pred_p, min_scores, part=20)

print('验证集')
pred_p2 = clf.predict_proba(x_test[columns])[:,1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr
print('test ks:  ' + str(max(ks2)))
r_p_chart2(y_test, pred_p2, min_scores, part=20)

print('全部数据')
pred_p3 = clf.predict_proba(x[columns])[:,1]
fpr, tpr, th = roc_curve(y, pred_p3)
ks3 = tpr - fpr
print('all ks:   ' + str(max(ks3)))
r_p_chart2(y, pred_p3, min_scores, part=20)


'''
1.1 先息后本中的模型表现
'''

print('训练集——先息后本')
xxhb_index =  ori_x_train.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([1,3,6])] )
obs = ori_y_train[xxhb_index]
p = clf.predict_proba(ori_x_train.loc[xxhb_index, columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20) 
    
print('验证集——先息后本')
xxhb_index =  x_test.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([1,3,6])] )
obs = y_test[xxhb_index]
p = clf.predict_proba(x_test.loc[xxhb_index, columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20)

print('全部数据——先息后本')
xxhb_index =  x.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([1,3,6])] )
obs = y[xxhb_index]
p = clf.predict_proba(x.loc[xxhb_index,columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20)
fpr, tpr, th = roc_curve(obs, p)
print('先息后本 ks: ' + str(max(tpr - fpr)))

'''
1.2 等本等息中的模型表现
'''

print('训练集——等本等息')
dbdx_index =  ori_x_train.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([12,24])] )
obs = ori_y_train[dbdx_index]
p = clf.predict_proba(ori_x_train.loc[dbdx_index,columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20)

print('验证集——等本等息')
dbdx_index =  x_test.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([12,24])] )
obs = y_test[dbdx_index]
p = clf.predict_proba(x_test.loc[dbdx_index,columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20)

print('全部数据——等本等息')
dbdx_index =  x.index.isin( sample_data.index[sample_data.TotalPhases_m.isin([12,24])] )
obs = y[dbdx_index]
p = clf.predict_proba(x.loc[dbdx_index,columns])[:,1]
r_p_chart2(obs, p, min_scores, part=20)
fpr, tpr, th = roc_curve(obs, p)
print('先息后本 ks: ' + str(max(tpr - fpr)))

model_data['grp'] = pd.cut(pred_p3 * 100.0, cuts, right=False)
score_dist  = model_data.groupby('grp').y.count()          
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)


'''
## 对全量申请样本进行评分
'''
cols = select_columns+['vehicle_evtrpt_b2bprice','vehicle_evtrpt_c2bprice','vehicle_evtrpt_evalprice3','vehicle_evtrpt_evalprice2']
xxdata = mdata.loc[mdata.loan_time.isin([1,3,6,12,24]), cols]
for col in date_columns:
    xxdata[col] = date_cal(xxdata[col], xxdata['app_applydate'])
    xxdata.loc[xxdata[col]==-1, col] = 0
    xxdata.loc[xxdata[col]<-1, col] = np.nan
    
for i, _ in de_dict.iterrows():
    name = de_dict.loc[i, 'var_name']
    default = de_dict.loc[i, 'default']
    if default != '""' and name in set(xxdata.columns) and name!='app_applydate' :
        try:
            xxdata[name] == int(default)
        except:
            continue
        if(sum(xxdata[name] == int(default))==0):
            xxdata[name] = xxdata[name].astype('float64')
        xxdata.loc[xxdata[name] == int(default), name] = np.nan

xxdata['vehicle_evtrpt_2bprice_gap'] = abs(xxdata['vehicle_evtrpt_b2bprice'] - xxdata['vehicle_evtrpt_c2bprice'])/xxdata['vehicle_evtrpt_b2bprice']
xxdata['vehicle_evtrpt_evalprice_trend'] = xxdata['vehicle_evtrpt_evalprice3']/xxdata['vehicle_evtrpt_evalprice2']

xxdata['apt_illegal_flag_1'] = xxdata.loc[:,'apt_illegal_flag'].isin([1]).astype('float64')
xxdata['apt_telecom_phoneattribution_2n3'] =  xxdata.loc[:,'apt_telecom_phoneattribution'].isin([2,3]).astype('float64')
xxdata['apt_socialsecurity_flag_1'] =  xxdata.loc[:,'apt_socialsecurity_flag'].isin([1]).astype('float64')
xxdata['apt_facetrial_residertogether_1n3'] =  xxdata.loc[:,'apt_facetrial_residertogether'].isin([1,3]).astype('float64') ##独居或和朋友同住
xxdata['apt_facetrial_housetype_1'] =  xxdata.loc[:,'apt_facetrial_housetype'].isin([1]).astype('float64')
xxdata['apt_facetrial_creditcardfalg_2'] =  xxdata.loc[:,'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
xxdata['apt_facetrial_otherhouseflag_0'] =  xxdata.loc[:,'apt_facetrial_otherhouseflag'].isin([0]).astype('float64')
xxdata['apt_facetrial_marry'] = xxdata['apt_facetrial_marry'].replace('已婚', '2').replace('未婚', '3').replace(np.nan, '6').str.slice(0,1)
xxdata['apt_facetrial_marry_2n5'] =  xxdata.loc[:,'apt_facetrial_marry'].isin(['2','5']).astype('float64')
xxdata['apt_comp_businesslicenseflag_1'] = xxdata.loc[:,'apt_comp_businesslicenseflag'].isin([1]).astype('float64')
xxdata[['apt_comp_jobcategory_2','apt_comp_jobcategory_NaN']] =  pd.get_dummies(xxdata['apt_comp_jobcategory'], dummy_na=True).iloc[:,1:]
xxdata[['vehicle_minput_lastmortgagerinfo_1', 'vehicle_minput_lastmortgagerinfo_2']] =  pd.get_dummies(xxdata['vehicle_minput_lastmortgagerinfo'], dummy_na=True).iloc[:,[0,1]]
xxdata['vehicle_minput_driverlicenseflag_1'] =  xxdata.loc[:,'vehicle_minput_driverlicenseflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_registcertflag_1'] =  xxdata.loc[:,'vehicle_minput_registcertflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_ownerway_1n2'] = xxdata.loc[:,'vehicle_minput_ownerway'].isin([1,2]).astype('float64')
xxdata[['vehicle_buymode_2','vehicle_buymode_NaN']] =  pd.get_dummies(xxdata['vehicle_buymode'], dummy_na=True).iloc[:,1:]
xxdata['tx_badinfor_is_EXIST'] = (xxdata.loc[:,'tx_badinfor_is'] == 'EXIST').astype('float64')
xxdata['tx_punish_history_NaN'] =  pd.get_dummies(xxdata['tx_punish_history'], dummy_na=True).iloc[:,1]
xxdata['code_td_loan_NaN'] =  pd.get_dummies(xxdata['code_td_loan'], dummy_na=True).iloc[:,1]
xxdata['td_dishonest_list_check_NaN'] =  pd.get_dummies(xxdata['td_dishonest_list_check'], dummy_na=True).iloc[:,1]
xxdata['code_yx_risk_NaN'] =  pd.get_dummies(xxdata['code_yx_risk'], dummy_na=True).iloc[:,1]

x = xxdata[columns]
x[x.isnull()] = -998
p = clf.predict_proba(x)[:,1]
x['grp'] = pd.cut(p * 100.0, cuts, right=False)
score_dist  = x.groupby('grp').grp.count()          
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)


## 生成新的20个分数区间
p = pd.Series(p) 
newcuts = [0.0] + round(p.quantile(np.linspace(0,1,21,endpoint=True)) * 100, 3).values.tolist()[1:20] + [100.0]
newgrp = pd.cut(p*100, newcuts, right=False)
score_dist  = newgrp.groupby(newgrp).count()         
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)

 
'''
## 对11月的申请进行评分
'''

m11_data =pd.read_table('data-201711.txt', delimiter='\u0001', dtype={'app_applycode':str})
m11_data = m11_data[(m11_data.app_applydate>='2017-11-01 00:00:00')&(m11_data.app_applydate<='2017-11-30 23:59:59')
                      & (m11_data.loan_mode=='押证') & (m11_data.app_applycode.isnull()==False)]
m11_data = m11_data.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
xxdata = m11_data.loc[m11_data.loan_time.isin([1,3,6,12,24]),cols]
xxdata = xxdata.replace('\\N', np.nan)

for col in date_columns:
    xxdata[col] = date_cal(xxdata[col], xxdata['app_applydate'])
    xxdata.loc[xxdata[col]==-1, col] = 0
    xxdata.loc[xxdata[col]<-1, col] = np.nan

for i, _ in de_dict.iterrows():
    name = de_dict.loc[i, 'var_name']
    default = de_dict.loc[i, 'default']
    if default != '""' and name in set(xxdata.columns) and name!='app_applydate' :
        try:
            xxdata[name] == int(default)
        except:
            continue
        if(sum(xxdata[name] == int(default))==0):
            xxdata[name] = xxdata[name].astype('float64')
        xxdata.loc[xxdata[name] == int(default), name] = np.nan

xxdata['vehicle_evtrpt_2bprice_gap'] = abs(xxdata['vehicle_evtrpt_b2bprice'] - xxdata['vehicle_evtrpt_c2bprice'])/xxdata['vehicle_evtrpt_b2bprice']
xxdata['vehicle_evtrpt_evalprice_trend'] = xxdata['vehicle_evtrpt_evalprice3']/xxdata['vehicle_evtrpt_evalprice2']
xxdata['apt_illegal_flag_1'] = xxdata.loc[:,'apt_illegal_flag'].isin([1]).astype('float64')
xxdata['apt_telecom_phoneattribution_2'] =  xxdata.loc[:,'apt_telecom_phoneattribution'].isin([2]).astype('float64')
xxdata['apt_socialsecurity_flag_1'] =  xxdata.loc[:,'apt_socialsecurity_flag'].isin([1]).astype('float64')
xxdata['apt_facetrial_residertogether_1n3'] =  xxdata.loc[:,'apt_facetrial_residertogether'].isin([1,3]).astype('float64') ##独居或和朋友同住
xxdata['apt_facetrial_housetype_1'] =  xxdata.loc[:,'apt_facetrial_housetype'].isin([1]).astype('float64')
xxdata['apt_facetrial_creditcardfalg_2'] =  xxdata.loc[:,'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
xxdata['apt_facetrial_otherhouseflag_0'] =  xxdata.loc[:,'apt_facetrial_otherhouseflag'].isin([0]).astype('float64')
xxdata['apt_facetrial_marry'] = xxdata['apt_facetrial_marry'].replace('已婚', '2').replace('未婚', '3').replace(np.nan, '6').str.slice(0,1)
xxdata['apt_facetrial_marry_2n5'] =  xxdata.loc[:,'apt_facetrial_marry'].isin(['2','5']).astype('float64')
xxdata['apt_comp_businesslicenseflag_1'] = xxdata.loc[:,'apt_comp_businesslicenseflag'].isin([1]).astype('float64')
xxdata[['apt_comp_jobcategory_2','apt_comp_jobcategory_NaN']] =  pd.get_dummies(xxdata['apt_comp_jobcategory'], dummy_na=True).iloc[:,1:]
xxdata[['vehicle_minput_lastmortgagerinfo_1', 'vehicle_minput_lastmortgagerinfo_2']] =  pd.get_dummies(xxdata['vehicle_minput_lastmortgagerinfo'], dummy_na=True).iloc[:,[0,1]]
xxdata['vehicle_minput_driverlicenseflag_1'] =  xxdata.loc[:,'vehicle_minput_driverlicenseflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_registcertflag_1'] =  xxdata.loc[:,'vehicle_minput_registcertflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_ownerway_1n2'] = xxdata.loc[:,'vehicle_minput_ownerway'].isin([1,2]).astype('float64')
xxdata[['vehicle_buymode_2','vehicle_buymode_NaN']] =  pd.get_dummies(xxdata['vehicle_buymode'], dummy_na=True).iloc[:,1:]
xxdata['tx_badinfor_is_EXIST'] = (xxdata.loc[:,'tx_badinfor_is'] == 'EXIST').astype('float64')
xxdata['tx_punish_history_NaN'] =  pd.get_dummies(xxdata['tx_punish_history'], dummy_na=True).iloc[:,1]
xxdata['code_td_loan_NaN'] =  xxdata['code_td_loan'].isnull() + 0.0  
xxdata['td_dishonest_list_check_NaN'] =  xxdata['td_dishonest_list_check'].isnull() + 0.0  
xxdata['code_yx_risk_NaN'] =  pd.get_dummies(xxdata['code_yx_risk'], dummy_na=True).iloc[:,1]
x = xxdata[columns]
x[x.isnull()] = -998
p = clf.predict_proba(x)[:,1]

## 用模型训练的分数段
x['grp'] = pd.cut(p * 100.0, cuts, right=False)
score_dist  = x.groupby('grp').grp.count()          
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)
## 用新分数段
p = pd.Series(p) 
newgrp = pd.cut(p*100, newcuts, right=False) # range(0,1.001,0.05))
score_dist  = newgrp.groupby(newgrp).count()         
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)


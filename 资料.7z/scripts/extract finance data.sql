
SELECT
  r.APPLYID,
  R.LOANNO,
  R.CONTRACTNO,
	R.PAYPHASES,
	p.LOANDATE,
	RD.SHOULDPAYDATE,
	RD.SHOULDCAPITAL,
	RD.ACTCAPITAL,
	RD.TOTALSHOULD,
	RD.TOTALACT ,
  RD.SHOULDGPSF ,
  RD.ACTGPSF ,
RD.SHOULDINT ,
RD.ACTINT ,
RD.SHOULDMANAGE,
RD.ACTMANAGE ,
 RD.SHOULDDELAYINT ,
 RD.SHOULDPENATY,
 RD.PAYDATE ,
pl.ISEXTENSION 
FROM
	ods_lms.tb_lf_return R,
	ods_lms.tb_lf_returndetail rd,
	ods_lms.tb_lm_payment p,
    ods_lms.tb_lm_payplan pl
WHERE
	r.id = rd.RETURNID
AND p.id = r.loanid and r.PAYPHASES=pl.PAYPHASES
AND pl.APPLYID=P.APPLYID
;


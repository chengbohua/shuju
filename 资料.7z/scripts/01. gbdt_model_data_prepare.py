﻿

import os
import pandas as pd 
import numpy as np
from scipy import stats
from sklearn.metrics import roc_curve
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.cross_validation import train_test_split
import pickle
import csv
import warnings
warnings.filterwarnings("ignore")


## 修改路径到数据存储的文件夹
os.chdir('Y:/czj/fraud_v2/data')


## 定义一些函数用于模型评估，计算KS
def r_p(y_test, answer_p, idx, low=0, high=150):
    a = answer_p
    b = y_test

    idx = idx[low:high]
    recall = (b.iloc[idx] == 1).sum() / (b == 1).sum()
    precision = (b.iloc[idx] == 1).sum() / (high - low)
    return (recall, precision)

def r_p_chart(y_test, answer_p, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    ths = []
    cum = 0
    if len(np.unique(a)) < part:
        for unq_a in np.unique(a)[::-1]:
            ths.append(cum)
            cum = cum + (a == unq_a).sum()
        ths.append(cum)

    else:
        for i in np.arange(0, len(a), (len(a) / part)):
            ths.append(int(round(i)))
        ths.append(len(a))

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        # idx_ths = 1
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]
        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]

        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))

    return min_scores


def r_p_chart2(y_test, answer_p, min_scores, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    ths = []
    ths.append(0)
    min_scores_idx = 0
    for num, i in enumerate(idx):
        # print(a[i])
        if a[i] < min_scores[min_scores_idx]:
            ths.append(num)
            min_scores_idx = min_scores_idx + 1
    ths.append(len(idx))

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]

        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]
        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))


'''
## 导入决策引擎数据，合同信息
'''

mdata0 =pd.read_table('data-1106.txt', delimiter='\u0001', dtype={'app_applycode':str})
apply_contract_report = pd.read_csv('applyid_applycode_htbh_1208.csv') 
apply_contract_report = apply_contract_report[(apply_contract_report.applycode.isnull()==False)&(apply_contract_report.contractno.isnull()==False)].sort_values(['applyid','contractno']).drop_duplicates('applyid', keep='last')


'''
## 申请窗口的数据(去重，删除申请号为空记录)
'''

start_date = '2017-05-16 00:00:00'
end_date = '2017-10-31 23:59:59'
mdata1 = mdata0[(mdata0.app_applydate>=start_date) & (mdata0.app_applydate<=end_date) & (mdata0.app_applycode.isnull()==False)]
mdata1=mdata1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata1 = pd.merge(mdata1, apply_contract_report, left_on='app_applycode', right_on='applycode', how='left')
mdata1['applymonth'] = mdata1.app_applydate.str.slice(0,7)  #生成申请月份
mdata1['loan_time_m'] = mdata1['loan_time']
mdata1.loc[mdata1.loan_time.isin([1,3,6,12,24])==False, 'loan_time_m'] = 998  #将其余的期限赋值为998期

print('申请窗口的总申请客户数: ', mdata1.shape[0]) 
print('申请窗口的1,3,6,12,24期限的总申请客户数: ', mdata1[mdata1.loan_time.isin([1,3,6,12,24])].shape[0])
count_stat_m = mdata1.groupby(['applymonth','loan_time_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode':'app_count'})
print(count_stat_m)

'''
## 导入财务数据，合并
'''

## 用TBD上的底层还款表计算曾经最大逾期天数（表现期截止到2017-11-30）
paymentdata0 =pd.read_table('payment-1207.txt', delimiter='\u0001', quoting=csv.QUOTE_NONE, encoding='utf-8')
paymentdata = paymentdata0[paymentdata0.loandate>=start_date]
paymentdata.loc[(paymentdata.paydate>='2017-12-01 00:00:00'), 'paydate'] = '2017-12-01 00:00:00' ## 将表现窗口设为截止到2017-11-30
paymentdata.loc[(paymentdata.shouldpaydate>='2017-12-07 00:00:00'), 'paydate'] = paymentdata.loc[(paymentdata.shouldpaydate>='2017-12-07 00:00:00'), 'shouldpaydate']

paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[ (paymentdata[['shouldcapital','shouldgpsf', 'shouldint', 'shouldmanage']]==0).all(axis=1), 'overdue_days'] = 0
paymentdata.loc[paymentdata['overdue_days']<0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days':'maxoverduedays'})

## 原表fnsche_over201710.csv读入有困难，另外建表fnsche_over201711_modified.csv，加入ReturnStatus_Label
## ReturnStatus_Label(0:未结清，1：已结清，2：手续已结清)
#findata0 = pd.read_csv('fnsche_over201710.csv')
findata0 = pd.read_csv('fnsche_over201711_modified.csv')  
findata0['LoanDate'] = pd.to_datetime(findata0['LoanDate']).astype('str')
findata = findata0[(findata0.LoanDate.str.slice(0,10) >= '2017-05-16')].rename(columns={'ContractNo':'contractno'})
findata = findata.sort_values(['contractno', 'LoanDate']).drop_duplicates('contractno', keep='last')
findata.LoanDate.min()
findata.LoanDate.max()
findata = pd.merge(findata, paymentdata_maxdue, on='contractno', how='left')

fin_mdata1 = pd.merge(mdata1, findata, on='contractno', how='inner')
fin_mdata1['TotalPhases_m'] =  fin_mdata1['TotalPhases']  ##实际贷款期限，与申请期限略有差别
fin_mdata1.loc[fin_mdata1.TotalPhases_m.isin([1,3,6,12,24])==False, 'TotalPhases_m'] = 998  ##其余期限改为998

print('申请窗口的总放款客户数: ', fin_mdata1.shape[0])
print('申请窗口的1,3,6,12,24期限的总放款客户数: ', fin_mdata1[fin_mdata1.TotalPhases.isin([1,3,6,12,24])].shape[0])

count_stat_fin_m = fin_mdata1.groupby(['applymonth','TotalPhases_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode':'fin_count'})
print(count_stat_fin_m)


'''
## 提取放款的押证客户
'''

mdata = mdata1[(mdata1.loan_mode=='押证') & (mdata1.app_applycode.isnull()==False)]
mdata = mdata.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
 
print('申请窗口的申请押证客户数: ', mdata.shape[0])
print('申请窗口的1,3,6,12,24期限的申请客户数：',  mdata[mdata.loan_time.isin([1,3,6,12,24])].shape[0]) 
print(mdata.groupby(['applymonth','loan_time_m']).app_applycode.agg('count'))

count_stat_yz_m = mdata.groupby(['applymonth','loan_time_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode':'app_count'})
print(count_stat_yz_m)

## 押证放款
fin_mdata = fin_mdata1[(fin_mdata1.loan_mode=='押证') & (fin_mdata1.app_applycode.isnull()==False)]
count_stat_yz_fin_m = fin_mdata.groupby(['applymonth','TotalPhases_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode':'fin_count'})
print(count_stat_yz_fin_m)

count_sample_m = pd.merge(pd.merge(count_stat_m, count_stat_yz_m, left_on=['applymonth','loan_time_m'], right_on=['applymonth','loan_time_m'], how='left'),
         pd.merge(count_stat_fin_m, count_stat_yz_fin_m, left_on=['applymonth','TotalPhases_m'], right_on=['applymonth','TotalPhases_m'], how='left'),
         left_on=['applymonth','loan_time_m'], right_on=['applymonth','TotalPhases_m'], how='left')
         

'''
## 读入字典
'''
tn_dict_1 = pd.read_excel('TouNa_DA-OAPPLIDT.xlsx')  ## 申请信息
tn_dict_2 = pd.read_excel('TouNa_DA-OBUREADT.xlsx')  ## 三方数据
tn_dict = tn_dict_1.append(tn_dict_2)
tn_dict['var_name'] = tn_dict.var_name.str.lower()

de_dict = pd.merge(tn_dict, pd.DataFrame(mdata.columns.tolist()), left_on='var_name', right_on=0, how='inner').drop(0,axis=1)

de_dict.to_excel('../result/DE_Var_Select_0.xlsx')



'''
----------------------------
## 定义好坏客户

## 坏客户定义：
#      1)  曾经逾期16+
## 好客户的定义： 
#      1） 已结清(包括1,3,6,12,24期)，未发生逾期， 
#      2） 针对6期客户，已还至少3期且未发生过逾期， 
#      3） 针对12期客户，已还至少4期且未发生过逾期，
#      4） 针对24期客户，已还至少4期且未发生过逾期
----------------------------
'''

my_data = fin_mdata.copy()
my_data['overdue_flag'] = (my_data.maxoverduedays>=16) | (my_data.CurrentdueDays>=16)  
my_data['bad'] = (my_data.overdue_flag==True) & (my_data.TotalPhases.isin([1,3,6,12,24]))
my_data['chargeoff_flag'] = (my_data.TotalDueDays==0) & (my_data.ReturnStatus_Label==1)
my_data['t6_good_flag'] = (my_data.ReturnPhases>=3) & (my_data.TotalPhases==6) & (my_data.TotalDueDays==0)
my_data['t12_good_flag'] = (my_data.ReturnPhases>=4) & (my_data.TotalPhases==12) & (my_data.TotalDueDays==0)
my_data['t24_good_flag'] = (my_data.ReturnPhases>=4) & (my_data.TotalPhases==24) & (my_data.TotalDueDays==0)
my_data['good'] = my_data.chargeoff_flag | my_data.t6_good_flag | my_data.t12_good_flag | my_data.t24_good_flag
my_data['y'] = np.nan
my_data.loc[(my_data.bad==True) & (my_data.good==False), 'y'] = 1
my_data.loc[(my_data.bad==False) & (my_data.good==True), 'y'] = 0

count_sample_m2 = pd.merge(count_sample_m, my_data[my_data.y.notnull()].groupby(['applymonth','TotalPhases_m']).agg({'y':['count', 'sum', 'mean'],'chargeoff_flag':['sum']}).reset_index(),
                                                   on=['applymonth','TotalPhases_m'], how='left')

print(count_sample_m2)

print(sum(my_data.bad))
#1636
print(sum(my_data.good))
#30255


## 针对1,3期，剔除灰样本
print(sum((my_data.TotalPhases.isin([1,3])) &  (my_data.y.isnull()))) 
## 针对6期，剔除灰样本
print(sum((my_data.TotalPhases==6) &  (my_data.y.isnull()))) 
## 针对12,24期，剔除灰样本
print(sum((my_data.TotalPhases.isin([12,24])) &  (my_data.y.isnull()))) 




'''
## 剔除变量缺失过高客户
'''
select_columns = ['app_applydate',
                 'apt_childnum',
                 'apt_currentaddrresideyears',
                 'apt_illegal_flag',
                 'apt_telecom_callfrequency',
                 'apt_telecom_phoneuserduration',
                 'apt_telecom_phoneattribution',
                 'apt_telecom_interconnectedcallsnum',
                 'apt_socialsecurity_flag',
                 'apt_age',
                 'apt_facetrial_residertogether',
                 'apt_facetrial_housetype',
                 'apt_facetrial_creditcardfalg',
                 'apt_facetrial_otherhouseflag',
                 'apt_facetrial_contactpersonnum',
                 'apt_facetrial_marry',
                 'apt_facetrial_localresideyears',
                 'apt_ec_lastloansettleddate',
                 'apt_ec_overduedaystotallastyear',
                 'apt_ec_longestoverduedaystotallastyear',
                 'apt_ec_overduephasetotallastyear',
                 'apt_ec_historyloantimes',
                 'apt_comp_businesslicenseflag',
                 'apt_comp_monthlysalary',
                 'apt_comp_experienceyears',
                 'apt_comp_jobcategory',
                 'apt_localresidemonths',
                 'vehicle_illegal_yearchargeamount',
                 'vehicle_illegal_penaltypoints',
                 'vehicle_illegal_num',
                 'vehicle_evtrpt_mileage',
                 'vehicle_evtrpt_transfersnums',
                 'vehicle_minput_lastreleasedate',
                 'vehicle_minput_lastmortgagerinfo',
                 'vehicle_minput_driverlicenseflag',
                 'vehicle_minput_registcertflag',
                 'vehicle_minput_obtaindate',
                 'vehicle_minput_ownerway',
                 'vehicle_minput_transfertimes',
                 'vehicle_minput_chargetimes',
                 'vehicle_buymode',
                 'fh_execu_annu_num',
                 'jxl_110_called_num',
                 'jxl_110_called_length',
                 'jxl_appear_num',
                 'jxl_tel_loan_call_sumnum',
                 'jxl_tel_length',
                 'jxl_black_interme_score',
                 'jxl_dir_black_num',
                 'jxl_eachphone_num',
                 'jxl_call_num_aver_6months',
                 'jxl_id_comb_othertel_num',
                 'jxl_turnoff_length',
                 'jxl_tel_credit_call_sumnum',
                 'jxl_nocturnal_ratio',
                 'jxl_black_dir_cont_num',
                 'jxl_contact1_num',
                 'jxl_contact1_rank',
                 'jxl_contact1_times',
                 'jxl_contact2_num',
                 'jxl_contact2_rank',
                 'jxl_contact2_times',
                 'jxl_contact3_num',
                 'jxl_contact3_rank',
                 'jxl_contact3_times',
                 'tx_badinfor_is',
                 'tx_punish_history',
                 'tx_num_cancel_status',
                 'code_td_loan',
                 'td_dishonest_list_check',
                 'yx_overdue_num_90days',
                 'code_yx_risk',
                 'yx_risk_num',
                 'yx_underly_record_num',
                 'yx_otherorgan_times']

high_null_samples = (my_data[select_columns].isnull().apply('mean', axis=1) > 0.75)
sum(high_null_samples)
## 0



'''
# 准备竞赛数据 (1,3,6,12,24期的好坏样本，特征未作处理)
'''

sample_data = my_data.loc[my_data.TotalPhases.isin([1,3,6,12,24]) & (my_data.loan_mode=='押证') & (my_data.y.isnull()==False), de_dict.var_name.tolist()+['y'] ]


if(0):
    x = sample_data[de_dict.var_name.tolist()]
    y = sample_data['y']
    sample_train,sample_test,y_train,y_test=train_test_split(x, y, test_size=0.2, stratify = y ,random_state=0)
    sample_train['y'] = y_train
    sample_test['y'] = y_test
    sample_train.to_csv('competition/sample_1215.txt', sep=',', index=False)
    sample_test.to_csv('competition/sample_test_1215.txt', sep=',', index=False)


'''
## 1. 进行数据清洗，字段统计
'''

xxdata = my_data[de_dict.var_name.tolist()]

'''
## 1.1 处理日期字段为距离申请日期的天数
'''

def date_cal(x, app_applydate):
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days

date_columns = ['apt_ec_lastloansettleddate',        
'vehicle_minput_lastreleasedate',       
'vehicle_minput_obtaindate'
]                      

highna_date_columns = ['apt_socialsecurity_enddate',
  'apt_socialsecurity_startdate',
  'apt_comp_registdate',
  'vehicle_minput_registcertdate',
  'vehicle_insurance_lastclaimsdate']

for col in date_columns:
    xxdata[col] = date_cal(xxdata[col], xxdata['app_applydate'])
    xxdata.loc[xxdata[col]==-1, col] = 0
    xxdata.loc[xxdata[col]<-1, col] = np.nan


'''
## 1.2 剔除全为空的字段,并把默认值设为空值
'''

print(xxdata.columns[xxdata.isnull().all()])

for i, _ in de_dict.iterrows():
    name = de_dict.loc[i, 'var_name']
    default = de_dict.loc[i, 'default']
    if default != '""' and name in set(xxdata.columns):
        try:
            xxdata[name] == int(default)
        except:
            continue
        xxdata.loc[xxdata[name] == int(default), name] = np.nan

'''
## 1.3 Define dummy variables for string-type variables
'''

str_columns = ['apt_illegal_flag',
'apt_telecom_phoneattribution',
'apt_socialsecurity_flag',
'apt_facetrial_residertogether',
'apt_facetrial_housetype',
'apt_facetrial_creditcardfalg',
'apt_facetrial_otherhouseflag',
'apt_facetrial_marry',
'apt_comp_businesslicenseflag',
'apt_comp_jobcategory',
'vehicle_minput_lastmortgagerinfo',
'vehicle_minput_driverlicenseflag',
'vehicle_minput_registcertflag',
'vehicle_minput_ownerway', 
'vehicle_buymode',
'tx_badinfor_is',
'tx_punish_history',
'code_td_loan',
'td_dishonest_list_check',
'code_yx_risk'
]

xxdata['apt_illegal_flag_1'] = xxdata.loc[:,'apt_illegal_flag'].isin([1]).astype('float64')
xxdata['apt_telecom_phoneattribution_2n3'] =  xxdata.loc[:,'apt_telecom_phoneattribution'].isin([2,3]).astype('float64')
xxdata['apt_socialsecurity_flag_1'] =  xxdata.loc[:,'apt_socialsecurity_flag'].isin([1]).astype('float64')
xxdata['apt_facetrial_residertogether_1n3'] =  xxdata.loc[:,'apt_facetrial_residertogether'].isin([1,3]).astype('float64') ##独居或和朋友同住
xxdata['apt_facetrial_housetype_1'] =  xxdata.loc[:,'apt_facetrial_housetype'].isin([1]).astype('float64')
xxdata['apt_facetrial_creditcardfalg_2'] =  xxdata.loc[:,'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
xxdata['apt_facetrial_otherhouseflag_0'] =  xxdata.loc[:,'apt_facetrial_otherhouseflag'].isin([0]).astype('float64')
xxdata['apt_facetrial_marry'] = xxdata['apt_facetrial_marry'].replace('已婚', '2').replace('未婚', '3').replace(np.nan, '6').str.slice(0,1)
xxdata['apt_facetrial_marry_2n5'] =  xxdata.loc[:,'apt_facetrial_marry'].isin(['2','5']).astype('float64')
xxdata['apt_comp_businesslicenseflag_1'] = xxdata.loc[:,'apt_comp_businesslicenseflag'].isin([1]).astype('float64')
xxdata[['apt_comp_jobcategory_2','apt_comp_jobcategory_NaN']] =  pd.get_dummies(xxdata['apt_comp_jobcategory'], dummy_na=True).iloc[:,1:]
xxdata[['vehicle_minput_lastmortgagerinfo_1', 'vehicle_minput_lastmortgagerinfo_2']] =  pd.get_dummies(xxdata['vehicle_minput_lastmortgagerinfo'], dummy_na=True).iloc[:,[0,1]]
xxdata['vehicle_minput_driverlicenseflag_1'] =  xxdata.loc[:,'vehicle_minput_driverlicenseflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_registcertflag_1'] =  xxdata.loc[:,'vehicle_minput_registcertflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_ownerway_1n2'] = xxdata.loc[:,'vehicle_minput_ownerway'].isin([1,2]).astype('float64')
xxdata[['vehicle_buymode_2','vehicle_buymode_NaN']] =  pd.get_dummies(xxdata['vehicle_buymode'], dummy_na=True).iloc[:,1:]
xxdata['tx_badinfor_is_EXIST'] = (xxdata.loc[:,'tx_badinfor_is'] == 'EXIST').astype('float64')
xxdata['tx_punish_history_NaN'] =  pd.get_dummies(xxdata['tx_punish_history'], dummy_na=True).iloc[:,1]
xxdata['code_td_loan_NaN'] =  pd.get_dummies(xxdata['code_td_loan'], dummy_na=True).iloc[:,1]
xxdata['td_dishonest_list_check_NaN'] =  pd.get_dummies(xxdata['td_dishonest_list_check'], dummy_na=True).iloc[:,1]
xxdata['code_yx_risk_NaN'] =  pd.get_dummies(xxdata['code_yx_risk'], dummy_na=True).iloc[:,1]

dummy_columns = ['apt_illegal_flag_1', 
              'apt_telecom_phoneattribution_2n3',
              'apt_socialsecurity_flag_1',
              'apt_facetrial_residertogether_1n3',
              'apt_facetrial_housetype_1',
              'apt_facetrial_creditcardfalg_2',
              'apt_facetrial_otherhouseflag_0', 
              'apt_facetrial_marry_2n5',
              'apt_comp_businesslicenseflag_1', 
              'apt_comp_jobcategory_2', 
              'vehicle_minput_lastmortgagerinfo_1', 'vehicle_minput_lastmortgagerinfo_2',
              'vehicle_minput_driverlicenseflag_1',
              'vehicle_minput_registcertflag_1',
              'vehicle_minput_ownerway_1n2', 
              'tx_badinfor_is_EXIST','tx_punish_history_NaN','code_td_loan_NaN', 'td_dishonest_list_check_NaN', 'code_yx_risk_NaN']


'''
## 变量的统计描述
'''

## 数值型
xxdesc = xxdata.describe().T
xxquantile = xxdata.quantile([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]).T
xxnullpct = xxdata.isnull().sum()
xxstat = pd.DataFrame(xxnullpct).rename(columns={0:'null_count'}) 
xxstat = pd.merge(xxstat,xxdesc,left_index=True,right_index=True)
xxstat= pd.merge(xxstat, xxquantile, left_index=True,right_index=True)
xxstat['var_name'] = xxstat.index
dict_desc = pd.merge(de_dict, xxstat, on='var_name', how='left')

## 非数值型的变量统计
for i in range(len(xxdata.columns)):
    if type(xxdata.iloc[0,i]) not in (np.float64, np.int64):
        print(xxdata.columns.values[i])
        dict_desc.loc[dict_desc.var_name==xxdata.columns.values[i], 'null_count'] = xxdata.iloc[:,i].isnull().sum()
        dict_desc.loc[dict_desc.var_name==xxdata.columns.values[i], 'count'] = xxdata.iloc[:,i].notnull().sum()
        
dict_desc.to_excel('../result/DE_Var_Select_1.xlsx')

'''
## 衍生变量
'''
xxdata['vehicle_evtrpt_2bprice_gap'] = abs(xxdata['vehicle_evtrpt_b2bprice'] - xxdata['vehicle_evtrpt_c2bprice'])/xxdata['vehicle_evtrpt_b2bprice']
xxdata['vehicle_evtrpt_evalprice_trend'] = xxdata['vehicle_evtrpt_evalprice3']/xxdata['vehicle_evtrpt_evalprice2']
xxdata['jxl_contact1_time_avg'] = xxdata['jxl_contact1_times']/xxdata['jxl_contact1_num']
xxdata['jxl_contact2_time_avg'] = xxdata['jxl_contact2_times']/xxdata['jxl_contact2_num']
xxdata['jxl_contact3_time_avg'] = xxdata['jxl_contact3_times']/xxdata['jxl_contact3_num']

my_data[xxdata.columns.tolist()] = xxdata.copy()


'''
## 选择初始变量
'''

numeric_columns = [select_columns[i] for i in range(len(select_columns)) 
                    if ((select_columns[i]!='app_applydate') & (select_columns[i] not in str_columns) & (select_columns[i] not in date_columns))]
numeric_columns = numeric_columns + ['vehicle_evtrpt_2bprice_gap', 'vehicle_evtrpt_evalprice_trend']  #+['jxl_contact1_time_avg','jxl_contact2_time_avg','jxl_contact3_time_avg']
numeric_columns.remove('apt_ec_longestoverduedaystotallastyear')  #剔除apt_ec_longestoverduedaystotallastyear


print(len(numeric_columns))
print(len(date_columns))
print(len(str_columns))


'''
## 汇集样本，单变量分析 (用 R作图)
'''

## ----------------------------------
## 提取样本集,只包含1,3,6,12,24期客户


sample_flag = my_data.y.notnull() & my_data.TotalPhases.isin([1,3,6,12,24]) & (high_null_samples==False)
sample_data = my_data[sample_flag]
sample_data.y.describe()
#count    31880.000000
#mean         0.051317
#std          0.220648


'''
## 样本的变量统计
'''

xxdata = sample_data[de_dict.var_name.tolist()]
xxdesc = xxdata.describe().T
xxquantile = xxdata.quantile([0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]).T
xxnullpct = xxdata.isnull().sum()
xxstat = pd.DataFrame(xxnullpct).rename(columns={0:'null_count'}) 
xxstat = pd.merge(xxstat,xxdesc,left_index=True,right_index=True)
xxstat= pd.merge(xxstat, xxquantile, left_index=True,right_index=True)
xxstat['var_name'] = xxstat.index
dict_desc = pd.merge(de_dict, xxstat, on='var_name', how='left')
for i in range(len(xxdata.columns)):
    if type(xxdata.iloc[0,i]) not in (np.float64, np.int64):
        print(xxdata.columns.values[i])
        dict_desc.loc[dict_desc.var_name==xxdata.columns.values[i], 'null_count'] = xxdata.iloc[:,i].isnull().sum()
        dict_desc.loc[dict_desc.var_name==xxdata.columns.values[i], 'count'] = xxdata.iloc[:,i].notnull().sum()     
#dict_desc.to_excel('../result/DE_Var_Sample_1.xlsx')


del findata0, paymentdata0, paymentdata, mdata1, apply_contract_report
del fin_mdata1, findata
del paymentdata_maxdue, my_data





'''
## 2. 模型训练
'''

ori_columns = numeric_columns + date_columns + dummy_columns 
model_data = sample_data.loc[:, ['y']+ori_columns]
xxhb_flag = sample_data.TotalPhases.isin([1,3,6]).astype('int64')
xxhb_index = sample_data[xxhb_flag==1].index
dbdx_index = sample_data[xxhb_flag==0].index 
xxdata = model_data[ori_columns]
xxdata = xxdata.drop(xxdata.columns[xxdata.isnull().all()], axis=1)
xxdata = xxdata.dropna(axis=1, how='all') 
xxdata[xxdata.isnull()] = -998
model_data[xxdata.columns.tolist()] = xxdata.copy()


## 拆分训练集和验证集   

y = model_data['y']
x = model_data[ori_columns]
x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.3,stratify = y ,random_state=0)
ori_x_train = x_train
ori_y_train = y_train  
bad = y_train[(y_train==1)]
bad_xxhb = y_train[(y_train==1) & y_train.index.isin(xxhb_index)] 
bad_dbdx = y_train[(y_train==1) & y_train.index.isin(dbdx_index)]     
good_xxhb = y_train[(y_train==0) & y_train.index.isin(xxhb_index)].sample(len(bad_xxhb)*5, random_state=0)
good_dbdx = y_train[(y_train==0) & y_train.index.isin(dbdx_index)].sample(len(bad_dbdx)*5, random_state=0)
y_train = pd.concat([bad_xxhb, good_xxhb, bad_dbdx, good_dbdx])
x_train = x_train.ix[y_train.index, :]
  
    
## 选取在模型中重要性不小于给定阈值的变量

tol = 0.01
columns = numeric_columns + date_columns + dummy_columns
a = range(len(columns)+1)
clf = GradientBoostingClassifier(learning_rate=0.05, 
                                     min_samples_leaf=20, 
                                     max_depth=5, 
                                     max_leaf_nodes=20, 
                                     n_estimators=20, 
                                     random_state=0)  
while (len(a)>len(columns)):    
    ## 训练模型并估计参数    
    clf.fit(x_train[columns], y_train)     
    pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
    fpr, tpr, th = roc_curve(ori_y_train, pred_p)
    ks = tpr - fpr
    pred_p2 = clf.predict_proba(x_test[columns])[:,1]
    fpr, tpr, th = roc_curve(y_test, pred_p2)
    ks2 = tpr - fpr
    print(columns)   
    print('len(columns)= ', len(columns))
    a = clf.feature_importances_.tolist()
    print('minimum feature importance = ', min(a))
    print('train ks: ' + str(max(ks)))
    print('test ks:  ' + str(max(ks2)))
    if( min(a) < tol ):
        b = (clf.feature_importances_ == min(a))
        columns = [columns[i] for i in range(len(columns)) if b[i]==False]

## 当变量个数为31时，模型总体表现最好

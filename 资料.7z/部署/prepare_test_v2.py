
rawcols = ['yx_otherorgan_times',
'jxl_id_comb_othertel_num',
'jxl_tel_length',
'jxl_black_dir_cont_num',
'apt_ec_overduedaystotallastyear',
'vehicle_minput_chargetimes',
'apt_ec_historyloantimes',
'apt_age',
'yx_underly_record_num',
'jxl_tel_loan_call_sumnum',
'jxl_turnoff_length',
'jxl_contact2_times',
'jxl_black_interme_score',
'apt_currentaddrresideyears',
'vehicle_evtrpt_mileage',
'apt_telecom_phoneuserduration',
'jxl_contact1_times',
'apt_comp_monthlysalary',
'vehicle_evtrpt_evalprice3',
'vehicle_evtrpt_evalprice2',
'td_dishonest_list_check',
'vehicle_minput_lastmortgagerinfo',
'apt_facetrial_housetype',
'vehicle_minput_ownerway',
'vehicle_minput_registcertflag',
'vehicle_minput_obtaindate',
'vehicle_minput_lastreleasedate',
'apt_ec_lastloansettleddate']

columns = ['yx_otherorgan_times',
'jxl_id_comb_othertel_num',
'jxl_tel_length',
'jxl_black_dir_cont_num',
'apt_ec_overduedaystotallastyear',
'vehicle_minput_chargetimes',
'apt_ec_historyloantimes',
'apt_age',
'yx_underly_record_num',
'jxl_tel_loan_call_sumnum',
'jxl_turnoff_length',
'jxl_contact2_times',
'jxl_black_interme_score',
'apt_currentaddrresideyears',
'vehicle_evtrpt_mileage',
'apt_telecom_phoneuserduration',
'jxl_contact1_times',
'apt_comp_monthlysalary',
'vehicle_evtrpt_evalprice_trend',
'td_dishonest_list_check_NaN',
'vehicle_minput_lastmortgagerinfo_1',
'apt_facetrial_housetype_1',
'vehicle_minput_ownerway_1n2',
'vehicle_minput_registcertflag_1',
'vehicle_minput_obtaindate',
'vehicle_minput_lastreleasedate',
'apt_ec_lastloansettleddate']


import pandas as pd
import os 
#testdata = x_test[columns].head(100)
#raw_testdata = fin_mdata.loc[testdata.head(100).index, rawcols]


testdata = pd.read_excel('Y:/czj/fraud_v2/部署/x_test.xlsx')
raw_testdata = pd.read_excel('Y:/czj/fraud_v2/部署/x_test_raw.xlsx')
testdata['antifraud_score'] =   clf.predict_proba(testdata[columns])[:, 1] * 100.0    
raw_testdata.loc[testdata.index[:2],['app_applydate']+rawcols].T

print(gbdt2('1',
'-99',
'209',
'102',
'0',
'1',
'8',
'52',
'0',
'-99',
'1',
'7.8',
'14',
'50',
'112669',
'209',
'2.05',
'50000',
'5.91',
'6.84',
'0',
'1',
'1',
'1',
'2',
'2015/7/6 0:00:00',
'2017/7/14 0:00:00',
'2017/7/14 0:00:00'
))


print(gbdt2('0',
'-99',
'125',
'61',
'0',
'3',
'0',
'46',
'0',
'5',
'1',
'-99',
'29',
'3',
'214237',
'120',
'-99',
'20000',
'4.85',
'5.4',
'0',
'1',
'5',
'3',
'2',
'2016/6/27	0:00:00',
'2017/4/27	0:00:00',
'')	)






 

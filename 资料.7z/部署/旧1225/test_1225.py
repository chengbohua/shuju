from sklearn.externals import joblib
import datetime
clf = joblib.load('gbdt2.pkl')

def gbdt2(yx_otherorgan_times,
        jxl_id_comb_othertel_num,
        jxl_black_dir_cont_num,
        jxl_tel_length,
        apt_ec_overduedaystotallastyear,
        apt_ec_historyloantimes,
        vehicle_minput_chargetimes,
        jxl_call_num_aver_6months,
        apt_age,
        yx_underly_record_num,
        jxl_turnoff_length,
        jxl_tel_loan_call_sumnum,
        vehicle_evtrpt_mileage,
        apt_currentaddrresideyears,
        apt_telecom_phoneuserduration,
        jxl_black_interme_score,
        jxl_contact1_times,
        apt_ec_overduephasetotallastyear,
        apt_comp_monthlysalary,
        jxl_contact2_times,
        jxl_contact1_rank,
        vehicle_evtrpt_evalprice3,
        vehicle_evtrpt_evalprice2,
        td_dishonest_list_check,
        apt_facetrial_housetype,
        vehicle_minput_lastmortgagerinfo,
        vehicle_minput_ownerway,
        vehicle_minput_registcertflag,
        vehicle_minput_obtaindate,
        vehicle_minput_lastreleasedate,
        apt_ec_lastloansettleddate):
    x1 = [yx_otherorgan_times,
        jxl_id_comb_othertel_num,
        jxl_black_dir_cont_num,
        jxl_tel_length,
        apt_ec_overduedaystotallastyear,
        apt_ec_historyloantimes,
        vehicle_minput_chargetimes,
        jxl_call_num_aver_6months,
        apt_age,
        yx_underly_record_num,
        jxl_turnoff_length,
        jxl_tel_loan_call_sumnum,
        vehicle_evtrpt_mileage,
        apt_currentaddrresideyears,
        apt_telecom_phoneuserduration,
        jxl_black_interme_score,
        jxl_contact1_times,
        apt_ec_overduephasetotallastyear,
        apt_comp_monthlysalary,
        jxl_contact2_times,
        jxl_contact1_rank]
    x2 = [vehicle_evtrpt_evalprice3,
          vehicle_evtrpt_evalprice2]
    x3 = [td_dishonest_list_check,
        apt_facetrial_housetype,
        vehicle_minput_lastmortgagerinfo,
        vehicle_minput_ownerway,
        vehicle_minput_registcertflag]
    dates = [vehicle_minput_obtaindate,
             vehicle_minput_lastreleasedate,
             apt_ec_lastloansettleddate]
    
    
    def fun(x):
        if x == '' or x == ' ' or float(x) == -1 or float(x) == -99:
            return -998
        else:
            return float(x)
        
    def fun_date(x):
        x = x.replace('/', '-')
        try:
            x = datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
        except:
            return -998
        now_time = datetime.datetime.now()
        x = (now_time - x).days
        return x
           
    try:
        x1 = [fun(i) for i in x1]
        x2 = [fun(i) for i in x2]
        dates = [fun_date(i) for i in dates]
    except:
        return -1
    
    # price devaluation trend
    if x2[0] == -998 or x2[0] == 0 or x2[1] == -998 or x2[1] == 0:
        vehicle_evtrpt_evalprice_trend = -998
    else:
        vehicle_evtrpt_evalprice_trend = x2[0] / x2[1]
    
    # dummies
    if x3[0] == '' or x3[0] == ' ':
        td_dishonest_list_check_NaN = 1.0
    else:
        td_dishonest_list_check_NaN = 0.0
    
    if x3[1] == '1':
        apt_facetrial_housetype_1 = 1.0
    else:
        apt_facetrial_housetype_1 = 0.0

    if x3[2] == '1':
        vehicle_minput_lastmortgagerinfo_1 = 1.0
    else:
        vehicle_minput_lastmortgagerinfo_1 = 0.0
                
    if x3[3] == '1' or x3[3] == '2':
        vehicle_minput_ownerway_1n2 = 1.0
    else:
        vehicle_minput_ownerway_1n2 = 0.0
           
    if x3[4] == '1':
        vehicle_minput_registcertflag_1 = 1.0
    else:
        vehicle_minput_registcertflag_1 = 0.0
        
    x3d = [td_dishonest_list_check_NaN,
          apt_facetrial_housetype_1,
          vehicle_minput_lastmortgagerinfo_1,
          vehicle_minput_ownerway_1n2,
          vehicle_minput_registcertflag_1]
    x = x1 + [vehicle_evtrpt_evalprice_trend] + x3d + dates
    
    res = float(clf.predict_proba(x)[:, 1]) * 100.0
    return '%.3f' % res

    
          
if __name__ == "__main__":
    print(gbdt2('2',
                '3',
                '10',
                '60',
                '4',
                '1',
                '1',
                '158.35',
                '26',
                '0',
                '2',
                '3',
                '99888',
                '5',
                '55',
                '60',
                '170.65',
                '2',
                '10000',
                '10.08',
                '3',
                '4.59',
                '5.08',
                'False',
                '1',
                '2',
                '1',
                '2',
                '2017/4/26  00:00:00',
                '2017/4/26  00:00:00',
                '2017/4/26  00:00:00')
          )


    
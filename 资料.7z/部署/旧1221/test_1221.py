from sklearn.externals import joblib
import datetime
clf = joblib.load('gbdt2.pkl')

def gbdt2(yx_otherorgan_times,
          vehicle_minput_obtaindate,
          jxl_id_comb_othertel_num,
          jxl_tel_length,
          jxl_black_dir_cont_num,
          vehicle_minput_lastreleasedate,
          apt_ec_historyloantimes,
          apt_ec_overduedaystotallastyear,
          apt_age,
          vehicle_evtrpt_evalprice3,
          vehicle_evtrpt_evalprice2,
          jxl_tel_loan_call_sumnum,
          jxl_call_num_aver_6months,
          td_dishonest_list_check,
          jxl_turnoff_length,
          vehicle_minput_lastmortgagerinfo,
          yx_underly_record_num,
          vehicle_minput_chargetimes,
          apt_facetrial_housetype,
          vehicle_evtrpt_mileage,
          apt_ec_lastloansettleddate,
          apt_ec_overduephasetotallastyear,
          apt_currentaddrresideyears,
          vehicle_minput_ownerway,
          apt_facetrial_creditcardfalg,
          jxl_contact2_times,
          apt_telecom_phoneuserduration,
          vehicle_minput_registcertflag,
          jxl_black_interme_score,
          apt_comp_monthlysalary,
          jxl_contact1_rank,
          jxl_contact1_times):
    x1 = [yx_otherorgan_times,
          jxl_id_comb_othertel_num,
          jxl_tel_length,
          jxl_black_dir_cont_num,
          apt_ec_historyloantimes,
          apt_ec_overduedaystotallastyear,
          apt_age,
          jxl_tel_loan_call_sumnum,
          jxl_call_num_aver_6months,
          jxl_turnoff_length,
          yx_underly_record_num,
          vehicle_minput_chargetimes,
          vehicle_evtrpt_mileage,
          apt_ec_overduephasetotallastyear,
          apt_currentaddrresideyears,
          jxl_contact2_times,
          apt_telecom_phoneuserduration,
          jxl_black_interme_score,
          apt_comp_monthlysalary,
          jxl_contact1_rank,
          jxl_contact1_times]
    x2 = [vehicle_evtrpt_evalprice3,
          vehicle_evtrpt_evalprice2]
    x3 = [td_dishonest_list_check,
          vehicle_minput_lastmortgagerinfo,
          apt_facetrial_housetype,
          vehicle_minput_ownerway,
          apt_facetrial_creditcardfalg,
          vehicle_minput_registcertflag]
    dates = [vehicle_minput_obtaindate,
             vehicle_minput_lastreleasedate,
             apt_ec_lastloansettleddate]
    
    
    def fun(x):
        if x == '' or x == ' ' or float(x) == -1 or float(x) == -99:
            return -998
        else:
            return float(x)
        
    def fun_date(x):
        x = x.replace('/', '-')
        try:
            x = datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
        except:
            return -998
        now_time = datetime.datetime.now()
        x = (now_time - x).days
        return x
           
    try:
        x1 = [fun(i) for i in x1]
        x2 = [fun(i) for i in x2]
        dates = [fun_date(i) for i in dates]
    except:
        return -1
    
    # price devaluation trend
    if x2[0] == -998 or x2[0] == 0 or x2[1] == -998 or x2[1] == 0:
        vehicle_evtrpt_evalprice_trend = -998
    else:
        vehicle_evtrpt_evalprice_trend = x2[0] / x2[1]
    
    # dummies
    if x3[0] == '' or x3[0] == ' ':
        td_dishonest_list_check_NaN = 1.0
    else:
        td_dishonest_list_check_NaN = 0.0
    
    if x3[1] == '1':
        vehicle_minput_lastmortgagerinfo_1 = 1.0
    else:
        vehicle_minput_lastmortgagerinfo_1 = 0.0

    if x3[2] == '1':
        apt_facetrial_housetype_1 = 1.0
    else:
        apt_facetrial_housetype_1 = 0.0
                
    if x3[3] == '1' or x3[3] == '2':
        vehicle_minput_ownerway_1n2 = 1.0
    else:
        vehicle_minput_ownerway_1n2 = 0.0
                        
    if x3[4] == '2':
        apt_facetrial_creditcardfalg_2 = 1.0
    else:
        apt_facetrial_creditcardfalg_2 = 0.0
        
    if x3[5] == '1':
        vehicle_minput_registcertflag_1 = 1.0
    else:
        vehicle_minput_registcertflag_1 = 0.0
        
    x3d = [td_dishonest_list_check_NaN,
          vehicle_minput_lastmortgagerinfo_1,
          apt_facetrial_housetype_1,
          vehicle_minput_ownerway_1n2,
          apt_facetrial_creditcardfalg_2,
          vehicle_minput_registcertflag_1]
    x = x1 + [vehicle_evtrpt_evalprice_trend] + x3d + dates
    
    res = float(clf.predict_proba(x)[:, 1]) * 100.0
    return '%.3f' % res

    
          
if __name__ == "__main__":
    print(gbdt2('0',
                '2013-08-20 00:00:00',
                '1',
                '126',
                '10',
                '2017-07-24 00:00:00',
                '0',
                '0',
                '36',
                '',
                '',
                '-99',
                '89.81667',
                '',
                '1',
                '2',
                '0',
                '1',
                '1',
                '79832',
                '',
                '0',
                '',
                '',
                '',
                '0.42',
                '126',
                '',
                '42',
                '6000',
                '-99',
                '-99')
          )



    
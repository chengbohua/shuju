#�ͻ���ʧԤ��ģ�ͽ��Ӵ���
#time:2018-05-08
var_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/new_var.csv')
var_new01 = var_new[,-c(17:32)] #ɾ����ͬ���ֵ���ͬ����
#������������ԭ�еı������к���ϲ�
khls_use_s = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_use_s.csv',row.names=1)
khls_use_now = merge(khls_use_s,var_new01,by="user_id")
khls_use_now = khls_use_now[,-221]#ɾ������x
khls_use_now = khls_use_now[,-237]#ɾ����ȫȱʧ����
khls_use_now = khls_use_now[,-237]#ɾ����ȫȱʧ����
#part the train_test
sub_5_17 = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/5_17_sub.csv',row.names=1)
#sub01 = sample(1:nrow(khls_use_now),round(nrow(khls_use_now)*0.7))
khls_train01 = khls_use_now[sub_5_17$x,]
y = khls_train01[,'ls']
y = y + 0.0
#�Ա�������woeת��
var_names = colnames(khls_use_now)
n_var = length(var_names)
khls_woe01 = data.frame(user_id = khls_train01[,'user_id'], y = khls_train01[,'ls'])
install.packages("dplyr")
require(dplyr)
khls_iv01 = data.frame(var_name = var_names[-1], IV=NA)
khls_levels01 = NULL #data.frame(bin=numeric(0),woe=numeric(0),bad_rate=numeric(0))
for(i in 3:n_var){
  x=khls_train01[,var_names[i]]
  breaks = c(-Inf, unique(quantile(x, prob=seq(0.1,0.9,0.1), na.rm=TRUE)), Inf)
  
  x_levels = cut(x, breaks, right=FALSE, labels=1:(length(breaks)-1))
  x_levels = as.numeric(x_levels)
  labs = sort(unique(na.omit(x_levels)))
  levs = levels(cut(x, breaks, right=FALSE))
  levs = levs[labs]
  if(sum(is.na(x))>=1){
    x_levels[is.na(x_levels)] = 999
    levs = c(levs, "NA")
  }
  
  data1 = data.frame(user_id=khls_train01[,1], y, x=x, label=x_levels)  
  x_ycounts = aggregate(y~x_levels, data=data1, FUN="length")
  x_ysums = aggregate(y~x_levels, data=data1, FUN="sum")
  x_ymeans = aggregate(y~x_levels, data=data1, FUN="mean")
  data2 = data.frame(levs, label=x_ycounts[,1], count=x_ycounts[,2],
                     bad = x_ysums[,2], bad_rate=x_ymeans[,2])
  ygoods = x_ycounts[,2] - x_ysums[,2]
  
  t = (x_ysums[,2] /sum(x_ysums[,2]))
  u = (ygoods  / sum(ygoods))
  for(j in 1:length(t)){
    if(t[j]==0){
      t[j] = 0.000001
    }
  }
  data2[,"woe"] = log( t / u )
  khls_levels01 = rbind(khls_levels01, data.frame(var_name=var_names[i], data2))
  
  data2 = data2[, c("label", "woe")]
  data3 = merge(data1, data2, by="label")
  xwoe_name = paste0(var_names[i], "_woe")
  data3[, xwoe_name] = data3[,"woe"]
  khls_woe01 = merge(khls_woe01, data3[, c("user_id", xwoe_name)], by="user_id")
  khls_iv01[i-1, "IV"] = sum((t-u)*data2$woe)
  
}
#����IVֵ�ĸߵ�ѡȡ139������
khls_iv2018_need01 = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/var_03_06.csv')
iv_names = colnames(khls_iv2018_need01)
for(i in 1:139){
  iv_names[i] = paste0(iv_names[i],"_woe")
}

khls_woe_train_new = khls_woe01[,c('user_id','y',iv_names[1:139])]
khls_woe_train_good_new = khls_woe_train_new[which(khls_woe_train_new$y == 0),]
sub1 <- sample(1:nrow(khls_woe_train_good_new),round(nrow(khls_woe_train_good_new)*0.091))
khls_woe_g_train_new = khls_woe_train_good_new[sub1,]
khls_woe_b_train_new = khls_woe_train_new[which(khls_woe_train_new$y == 1),]
khls_woe1_new_new = rbind(khls_woe_g_train_new,khls_woe_b_train_new)
khls_woe1_new_new = khls_woe1_new_new[,which(colnames(khls_woe1_new_new)!='user_id')]
fit1_new = glm(y~.,khls_woe1_new_new,family="binomial")

#��ȡ��ɸѡ�Ľ�ģ����
var_need = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/var_need.csv')
name_002 = colnames(var_need)
khls_woe_train04_new = khls_woe_train_new[,name_002[1:15]]
khls_woe_3_16 = rbind(khls_woe_g_train_new,khls_woe_b_train_new)
khls_woe3_new_new01 = khls_woe_3_16[,name_002[1:15]]
khls_5_17_fit = khls_woe1_new_new[,name_002[1:15]]
fit1_new01_new = glm(y~.,khls_5_17_fit,family="binomial")
pre1_new01_new = predict(fit1_new01_new,type="response",newdata=khls_woe_train04_new)
#install.packages("pROC")
#library(pROC)
#modelroc1_new01_2 = roc(khls_woe_train04_new$y[1:1000],pre1_new01_new[1:1000])
#plot(modelroc1_new01_2,print.auc=TRUE,auc.polygon=TRUE,grid=c(0.1,0.2),grid.col=c("green","red"),max.auc.polygon=TRUE,auc.polygon.col="brown",print.thres=TRUE)
install.packages("ROCR")
library(ROCR)
pred <- prediction(predictions=pre1_new01_new,labels=khls_woe_train04_new$y)
perf <- performance(pred,measure="tpr",x.measure="fpr")
plot(perf,main="�ͻ���ʧԤ��ģ�͵�ROC����",
     col="blue",lwd=3)
abline(a=0,b=1,lwd=2,lty=2)
perf_auc <- performance(pred,measure="auc")
unlist(perf_auc@y.values)
install.packages("car")
library(car)
vif(fit1_new01_new)
#ģ�ͱ��������ϵ������
x_t01_new = rbind(khls_woe_train04_new[,2:15])
x_cor01_new = cor(x_t01_new)
#ѵ������ks
#install.packages("ROCR")
myks<-function(y,pre){
  
  library(ROCR)
  
  pred <- prediction(predictions=pre,labels=y)
  
  perf <- performance(pred,"tpr","fpr")
  
  tmp<-max(attr(perf,"y.values")[[1]]-attr(perf,"x.values")[[1]])
  
  return(tmp)
  
}
myks(khls_woe_train04_new$y,pre1_new01_new)

var_name_06_new = unlist(strsplit(name_002[2:15],'_woe'))
#��ȡ��ģ��15�������ķ���ˮƽ
khls_levels03_06 = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_levels03_06.csv')
khls_levels03_06_n01 = NA
for(i in 1:14){
  khls_levels03_06_n01 = rbind(khls_levels03_06_n01,khls_levels03_06[which(khls_levels03_06$'������' == var_name_06_new[i]),])
}
write.csv(khls_levels03_06_n01,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_levels03_16_n.csv')
#���Լ�
khls_test = khls_use_now[-sub_5_17$x,]
y = khls_test[,'ls']
y = y + 0.0
khls_test_new_01 = khls_test[,c('user_id',var_name_06_new[1:14])]
var_names02 = colnames(khls_test_new_01)
n_var02 = length(var_names02)
khls_woe_02 = data.frame(user_id = khls_test[,'user_id'], y = khls_test[,'ls'])
khls_woe_03 = data.frame(last_twelve_fund_inflow_woe = rep(NA,20658),last_three_month_collect_ratio_woe=rep(NA,20658),
                         last_twelve_month_avg_join_inter_woe = rep(NA,20658),avg_last_twelve_tender_money_woe = rep(NA,20658),
                         last_one_ratio_avg_twelve_woe = rep(NA,20658),last_one_month_asset_ratio_woe = rep(NA,20658),
                         last_twelve_tender_times_woe = rep(NA,20658),last_one_month_use_change_woe = rep(NA,20658),
                         last_one_month_award_money_woe = rep(NA,20658),last_twelve_t_tender_to_repay_woe = rep(NA,20658),
                         last_three_tixian_inter_woe = rep(NA,20658),last_one_hk_money_woe = rep(NA,20658),
                         last_one_suc_rec_money_woe = rep(NA,20658),last_three_tender_money_woe = rep(NA,20658))
#��ֵ��khls_levels2018_04_new
khls_levels2018_04_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_levels03_16_n.csv')
khls_levels2018_04_new = khls_levels2018_04_new[-1,]
khls_levels2018_04_new = khls_levels2018_04_new[,-1]

#����ѵ�����ķ���
khls_levels2018_04_new01 = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/var_train_n.csv')
khls_woe_train_n01 = data.frame(y = khls_train01[,'ls'],last_twelve_fund_inflow_woe = rep(NA,48201),last_three_month_collect_ratio_woe=rep(NA,48201),
                                last_twelve_month_avg_join_inter_woe = rep(NA,48201),avg_last_twelve_tender_money_woe = rep(NA,48201),
                                last_one_ratio_avg_twelve_woe = rep(NA,48201),last_one_month_asset_ratio_woe = rep(NA,48201),
                                last_twelve_tender_times_woe = rep(NA,48201),last_one_month_use_change_woe = rep(NA,48201),
                                last_one_month_award_money_woe = rep(NA,48201),last_twelve_t_tender_to_repay_woe = rep(NA,48201),
                                last_three_tixian_inter_woe = rep(NA,48201),last_one_hk_money_woe = rep(NA,48201),
                                last_one_suc_rec_money_woe = rep(NA,48201),last_three_tender_money_woe = rep(NA,48201))
khls_woe_03 = khls_woe_train_n01
var_names08 = var_names02
n_var03 = length(var_names08)
for(i in 2:n_var03){
  x=khls_train01[,var_names08[i]]
  if(i == 2){
    breaks = c(-Inf,-1.69e+04,7.27e+03,1.21e+04,1.98e+04,3e+04,4.91e+04,1.4e+05,Inf)
  }
  else if(i == 3){
    breaks = c(-Inf,-0.816,-0.302,0.0344,0.157,0.428, Inf)
  }else if(i == 4){
    breaks = c(-Inf,43.8,120,162,224,254,Inf)
  }
  else if(i == 5){
    breaks = c(-Inf,2.78e+03,4.5e+03,5.98e+03,7.99e+03,1e+04,1.25e+04,1.56e+04,2.06e+04,3.31e+04,Inf)
  }else if(i == 6){
    breaks = c(-Inf,0.09189,0.2594,0.5058,0.7491,1.003,1.235,Inf)
  }else if(i == 7){
    breaks = c(-Inf,-0.124,0.00674,0.00747,0.00814,0.00921,0.0336,0.366,Inf)
  }else if(i == 8){
    breaks = c(-Inf,2,3,4,5,12,19,34,Inf)
  }else if(i == 9){
    breaks = c(-Inf,-90,0,31.2,287,Inf)
  }else if(i == 10){
    breaks = c(0,0.0879,0.25,0.43,3.09,Inf)
  }else if(i == 11){
    breaks = c(-Inf,0.5,0.836,1.71,2,2.5,3.5,Inf)
  }else if(i == 12){
    breaks = c(0,45,61,73,Inf)
  }else if(i == 13){
    breaks = c(0,127,1.57e+03,1.14e+04,3.11e+04,Inf)
  }else if(i == 14){
    breaks = c(0,1.68e+04,Inf)
  }else if(i == 15){
    breaks = c(0,50,5.12e+03,1.02e+04,2e+04,3e+04,5e+04,9.52e+04,Inf)
  }
  
  
  x_levels = cut(x, breaks, right=FALSE, labels=1:(length(breaks)-1))
  if(i == 2){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[9,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[1,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[2,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[3,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[4,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[5,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[6,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[7,7]}
      else if(x_levels[j]==8){
        khls_woe_03[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[8,7]}
      
    }
    
  }
  if(i == 3){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[16,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[10,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[11,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[12,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[13,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[14,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[15,7]}
      
    }
    
  }
  
  if(i == 4){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[23,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[17,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[18,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[19,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[20,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[21,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[22,7]}
      
    }
    
  }
  if(i == 5){
    for(j in 1:48201){
      if(x_levels[j]==10){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[33,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[24,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[25,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[26,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[27,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[28,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[29,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[30,7]}
      else if(x_levels[j]==8){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[31,7]}
      else if(x_levels[j]==9){
        khls_woe_03[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[32,7]}
      
    }
    
  }
  if(i == 6){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[41,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[34,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[35,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[36,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[37,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[38,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[39,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[40,7]}
    }
    
  }
  
  if(i == 7){
    for(j in 1:48201){
      if(x_levels[j]==8){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[49,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[42,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[43,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[44,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[45,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[46,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[47,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[48,7]}
      
    }
    
  }
  if(i == 8){
    for(j in 1:48201){
      if(x_levels[j]==8){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[57,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[50,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[51,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[52,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[53,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[54,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[55,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[56,7]}
      
    }
    
  }
  if(i == 9){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[63,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[58,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[59,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[60,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[61,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[62,7]}
    }
    
  }
  if(i == 10){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[69,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[64,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[65,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[66,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[67,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[68,7]}
    }
    
  }
  if(i == 11){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[77,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[70,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[71,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[72,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[73,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[74,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[75,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[76,7]}
    }
    
  }
  if(i == 12){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[82,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[78,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[79,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[80,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[81,7]}
    }
    
  }
  if(i == 13){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[88,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[83,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[84,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[85,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[86,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[87,7]}
    }
    
  }
  if(i == 14){
    for(j in 1:48201){
      if(is.na(x_levels[j])){
        khls_woe_03[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[91,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[89,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[90,7]}
      
    }
    
  }
  if(i == 15){
    for(j in 1:48201){
      if(x_levels[j]==8){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[99,7]
      }else if(x_levels[j]==1){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[92,7]
      }else if(x_levels[j]==2){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[93,7]}
      else if(x_levels[j]==3){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[94,7]}
      else if(x_levels[j]==4){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[95,7]}
      else if(x_levels[j]==5){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[96,7]}
      else if(x_levels[j]==6){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[97,7]}
      else if(x_levels[j]==7){
        khls_woe_03[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[98,7]}
      
    }
  }
}

khls_woe_train_good_new1 = khls_woe_03[which(khls_woe_03$y == 0),]
sub1 <- sample(1:nrow(khls_woe_train_good_new1),round(nrow(khls_woe_train_good_new1)*0.091))
khls_woe_g_train_new1 = khls_woe_train_good_new1[sub1,]
khls_woe_b_train_new1 = khls_woe_03[which(khls_woe_03$y == 1),]
khls_5_17_p = rbind(khls_woe_g_train_new1,khls_woe_b_train_new1)
fit1_5_17 = glm(y~.,khls_5_17_p,family="binomial")
pre3_new01_new = predict(fit1_5_17,type="response",newdata=khls_woe_03)
#modelroc3_new03_16 = roc(khls_woe_03$y,pre3_new01_new)
#plot(modelroc3_new03_16,print.auc=TRUE,auc.polygon=TRUE,grid=c(0.1,0.2),grid.col=c("green","red"),max.auc.polygon=TRUE,auc.polygon.col="brown",print.thres=TRUE)
pred01 <- prediction(predictions=pre3_new01_new,labels=khls_woe_03$y)
perf01 <- performance(pred01,measure="tpr",x.measure="fpr")
plot(perf01,main="�ͻ���ʧԤ��ģ��ѵ������ROC����",
     col="blue",lwd=3)
abline(a=0,b=1,lwd=2,lty=2)
perf_auc01 <- performance(pred01,measure="auc")
unlist(perf_auc01@y.values)
myks(khls_woe_03$y,pre3_new01_new)

#�������Լ��ķ���
khls_woe_03_test = data.frame(last_twelve_fund_inflow_woe = rep(NA,20658),last_three_month_collect_ratio_woe=rep(NA,20658),
                              last_twelve_month_avg_join_inter_woe = rep(NA,20658),avg_last_twelve_tender_money_woe = rep(NA,20658),
                              last_one_ratio_avg_twelve_woe = rep(NA,20658),last_one_month_asset_ratio_woe = rep(NA,20658),
                              last_twelve_tender_times_woe = rep(NA,20658),last_one_month_use_change_woe = rep(NA,20658),
                              last_one_month_award_money_woe = rep(NA,20658),last_twelve_t_tender_to_repay_woe = rep(NA,20658),
                              last_three_tixian_inter_woe = rep(NA,20658),last_one_hk_money_woe = rep(NA,20658),
                              last_one_suc_rec_money_woe = rep(NA,20658),last_three_tender_money_woe = rep(NA,20658))


for(i in 2:n_var03){
  x=khls_test[,var_names08[i]]
  if(i == 2){
    breaks = c(-Inf,-1.69e+04,7.27e+03,1.21e+04,1.98e+04,3e+04,4.91e+04,1.4e+05,Inf)
  }
  else if(i == 3){
    breaks = c(-Inf,-0.816,-0.302,0.0344,0.157,0.428, Inf)
  }else if(i == 4){
    breaks = c(-Inf,43.8,120,162,224,254,Inf)
  }
  else if(i == 5){
    breaks = c(-Inf,2.78e+03,4.5e+03,5.98e+03,7.99e+03,1e+04,1.25e+04,1.56e+04,2.06e+04,3.31e+04,Inf)
  }else if(i == 6){
    breaks = c(-Inf,0.09189,0.2594,0.5058,0.7491,1.003,1.235,Inf)
  }else if(i == 7){
    breaks = c(-Inf,-0.124,0.00674,0.00747,0.00814,0.00921,0.0336,0.366,Inf)
  }else if(i == 8){
    breaks = c(-Inf,2,3,4,5,12,19,34,Inf)
  }else if(i == 9){
    breaks = c(-Inf,-90,0,31.2,287,Inf)
  }else if(i == 10){
    breaks = c(0,0.0879,0.25,0.43,3.09,Inf)
  }else if(i == 11){
    breaks = c(-Inf,0.5,0.836,1.71,2,2.5,3.5,Inf)
  }else if(i == 12){
    breaks = c(0,45,61,73,Inf)
  }else if(i == 13){
    breaks = c(0,127,1.57e+03,1.14e+04,3.11e+04,Inf)
  }else if(i == 14){
    breaks = c(0,1.68e+04,Inf)
  }else if(i == 15){
    breaks = c(0,50,5.12e+03,1.02e+04,2e+04,3e+04,5e+04,9.52e+04,Inf)
  }
  
  
  x_levels = cut(x, breaks, right=FALSE, labels=1:(length(breaks)-1))
  if(i == 2){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[9,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[1,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[2,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[3,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[4,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[5,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[6,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[7,7]}
      else if(x_levels[j]==8){
        khls_woe_03_test[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[8,7]}
      
    }
    
  }
  if(i == 3){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[16,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[10,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[11,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[12,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[13,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[14,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[15,7]}
      
    }
    
  }
  
  if(i == 4){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[23,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[17,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[18,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[19,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[20,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[21,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[22,7]}
      
    }
    
  }
  if(i == 5){
    for(j in 1:20658){
      if(x_levels[j]==10){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[33,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[24,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[25,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[26,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[27,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[28,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[29,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[30,7]}
      else if(x_levels[j]==8){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[31,7]}
      else if(x_levels[j]==9){
        khls_woe_03_test[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[32,7]}
      
    }
    
  }
  if(i == 6){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[41,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[34,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[35,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[36,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[37,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[38,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[39,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[40,7]}
    }
    
  }
  
  if(i == 7){
    for(j in 1:20658){
      if(x_levels[j]==8){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[49,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[42,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[43,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[44,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[45,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[46,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[47,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[48,7]}
      
    }
    
  }
  if(i == 8){
    for(j in 1:20658){
      if(x_levels[j]==8){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[57,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[50,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[51,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[52,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[53,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[54,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[55,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[56,7]}
      
    }
    
  }
  if(i == 9){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[63,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[58,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[59,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[60,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[61,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[62,7]}
    }
    
  }
  if(i == 10){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[69,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[64,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[65,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[66,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[67,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[68,7]}
    }
    
  }
  if(i == 11){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[77,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[70,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[71,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[72,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[73,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[74,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[75,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[76,7]}
    }
    
  }
  if(i == 12){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[82,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[78,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[79,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[80,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[81,7]}
    }
    
  }
  if(i == 13){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[88,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[83,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[84,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[85,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[86,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[87,7]}
    }
    
  }
  if(i == 14){
    for(j in 1:20658){
      if(is.na(x_levels[j])){
        khls_woe_03_test[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[91,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[89,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[90,7]}
      
    }
    
  }
  if(i == 15){
    for(j in 1:20658){
      if(x_levels[j]==8){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[99,7]
      }else if(x_levels[j]==1){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[92,7]
      }else if(x_levels[j]==2){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[93,7]}
      else if(x_levels[j]==3){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[94,7]}
      else if(x_levels[j]==4){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[95,7]}
      else if(x_levels[j]==5){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[96,7]}
      else if(x_levels[j]==6){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[97,7]}
      else if(x_levels[j]==7){
        khls_woe_03_test[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[98,7]}
      
    }
  }
}
#������Ĳ��Լ�Ч��
pre4_3_16 = predict(fit1_5_17,type="response",newdata=khls_woe_03_test)
#modelroc4_16 = roc(khls_test$ls,pre4_3_16)
#plot(modelroc4_16,print.auc=TRUE,auc.polygon=TRUE,grid=c(0.1,0.2),grid.col=c("green","red"),max.auc.polygon=TRUE,auc.polygon.col="brown",print.thres=TRUE)
myks(khls_test$ls,pre4_3_16)

pred02 <- prediction(predictions=pre4_3_16,labels=khls_test$ls)
perf02 <- performance(pred02,measure="tpr",x.measure="fpr")
plot(perf02,main="�ͻ���ʧԤ��ģ�Ͳ��Լ���ROC����",
     col="blue",lwd=3)
abline(a=0,b=1,lwd=2,lty=2)
perf_auc02 <- performance(pred02,measure="auc")
unlist(perf_auc02@y.values)

#���Ƶ���������bad_rate����
#write.csv(khls_levels2018_04_new01,file = 'E:/khls_levels_3_16.csv')
khls_levels_3_16 = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_levels_3_16.csv')
var_name_07 = var_names08[-1]
install.packages("plotrix")
library(plotrix)
for(i in 1:14){
  khls_woe_select = khls_levels_3_16[which(khls_levels_3_16$var_name == var_name_07[i]),]
  
  twoord.plot(lx=1:nrow(khls_woe_select), rx = 1:nrow(khls_woe_select),ry=khls_woe_select$bad_rate,ly=khls_woe_select$count, type=c('bar','l'), xaxt='n',lcol="brown",rcol="blue",
              xlab=var_name_07[i],ylab="count",rylab = "bad rate",main='bad rate curve',lwd = 2,xticklab = khls_woe_select$levs)
  
}

#ѵ����ģ��ʹ�ý���
write.csv(pre3_new01_new,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre3_new01_new.csv')
pre3_new01_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre3_new01_new.csv')
pre3_ls01 = data.frame(ls_rate = pre3_new01_new$x,ls_flag = khls_woe_train_n01$y)
breaks01 = quantile(pre3_ls01$ls_rate,prob = seq(0,1,0.05))
pre3_levels = cut(pre3_ls01$ls_rate, breaks01, right=FALSE, labels=1:(length(breaks01)-1))
levs01 = levels(cut(pre3_ls01$ls_rate, breaks01, right=FALSE))
model_use_03_16 = data.frame(ls_rate = pre3_ls01$ls_rate, ls_flag = pre3_ls01$ls_flag,label = pre3_levels,space = rep(NA,48201))
for(i in 1:48201){
  for(j in 1:20){
    if(is.na(model_use_03_16[i,3])){
      model_use_03_16[i,'space'] = model_use_03_16[i,'ls_rate']
    }
    else if(model_use_03_16[i,3]==j){
      model_use_03_16[i,'space'] = levs01[j]
    }
  }
}
write.csv(model_use_03_16,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_03_16.csv')

install.packages('dplyr')
require(dplyr)
model_use_train_03_16 = data.frame(avg_score = rep(NA,20),max_score = rep(NA,20),min_score =rep(NA,20),bad=rep(NA,20),good = rep(NA,20))
avg_score = aggregate(model_use_03_16$ls_rate~model_use_03_16$label, data=model_use_03_16, FUN="mean")
max_score = aggregate(model_use_03_16$ls_rate~model_use_03_16$label,data = model_use_03_16,FUN = "max")
min_score = aggregate(model_use_03_16$ls_rate~model_use_03_16$label,data = model_use_03_16,FUN = "min")
total_count = aggregate(model_use_03_16$ls_flag~model_use_03_16$label,data = model_use_03_16,FUN = "length")
bad_count = aggregate(model_use_03_16$ls_flag~model_use_03_16$label,data = model_use_03_16,FUN = "sum")


model_use_train_03_16 = data.frame(avg_score01 = avg_score[,2],max_score01 = max_score[,2],
                                   min_score01 = min_score[,2],total_count01 = total_count[,2],
                                   bad_count01 = bad_count[,2])

write.csv(model_use_train_03_16,'//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_train_03_16.csv')

#���Լ�ģ��ʹ�ý���
write.csv(pre4_3_16,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre4_3_16.csv')
pre4_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre4_3_16.csv')
pre4_ls02 = data.frame(ls_rate = pre4_new$x,ls_flag = khls_test$ls)
#breaks02 = quantile(pre4_ls02$ls_rate,prob = seq(0,1,0.05))
pre4_levels = cut(pre4_ls02$ls_rate, breaks01, right=FALSE, labels=1:(length(breaks01)-1))
levs02 = levels(cut(pre4_ls02$ls_rate, breaks01, right=FALSE))
model_use_3_16_test = data.frame(ls_rate = pre4_ls02$ls_rate, ls_flag = pre4_ls02$ls_flag,label = pre4_levels,space = rep(NA,20658))
for(i in 1:20658){
  for(j in 1:20){
    if(is.na(model_use_3_16_test[i,3])){
      model_use_3_16_test[i,'space'] = model_use_3_16_test[i,'ls_rate']
    }
    else if(model_use_3_16_test[i,3]==j){
      model_use_3_16_test[i,'space'] = levs02[j]
    }
  }
}

write.csv(model_use_3_16_test,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_3_16_test.csv')

model_use_test_3_16 = data.frame(avg_score = rep(NA,20),max_score = rep(NA,20),min_score =rep(NA,20),bad=rep(NA,20),good = rep(NA,20))
avg_score = aggregate(model_use_3_16_test$ls_rate~model_use_3_16_test$label, data=model_use_3_16_test, FUN="mean")
max_score = aggregate(model_use_3_16_test$ls_rate~model_use_3_16_test$label,data = model_use_3_16_test,FUN = "max")
min_score = aggregate(model_use_3_16_test$ls_rate~model_use_3_16_test$label,data = model_use_3_16_test,FUN = "min")
total_count = aggregate(model_use_3_16_test$ls_flag~model_use_3_16_test$label,data = model_use_3_16_test,FUN = "length")
bad_count = aggregate(model_use_3_16_test$ls_flag~model_use_3_16_test$label,data = model_use_3_16_test,FUN = "sum")

model_use_test_3_16 = data.frame(avg_score02 = avg_score[,2],max_score02 = max_score[,2],
                                 min_score02 = min_score[,2],total_count02 = total_count[,2],
                                 bad_count02 = bad_count[,2])

write.csv(model_use_test_3_16,'//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_test_3_16.csv')

#ȫ��������
khls_woe_2018_all_316 = data.frame(last_twelve_fund_inflow_woe = rep(NA,68859),last_three_month_collect_ratio_woe=rep(NA,68859),
                                   last_twelve_month_avg_join_inter_woe = rep(NA,68859),avg_last_twelve_tender_money_woe = rep(NA,68859),
                                   last_one_ratio_avg_twelve_woe = rep(NA,68859),last_one_month_asset_ratio_woe = rep(NA,68859),
                                   last_twelve_tender_times_woe = rep(NA,68859),last_one_month_use_change_woe = rep(NA,68859),
                                   last_one_month_award_money_woe = rep(NA,68859),last_twelve_t_tender_to_repay_woe = rep(NA,68859),
                                   last_three_tixian_inter_woe = rep(NA,68859),last_one_hk_money_woe = rep(NA,68859),
                                   last_one_suc_rec_money_woe = rep(NA,68859),last_three_tender_money_woe = rep(NA,68859))


for(i in 2:n_var03){
  x=khls_use_now[,var_names08[i]]
  if(i == 2){
    breaks = c(-Inf,-1.69e+04,7.27e+03,1.21e+04,1.98e+04,3e+04,4.91e+04,1.4e+05,Inf)
  }
  else if(i == 3){
    breaks = c(-Inf,-0.816,-0.302,0.0344,0.157,0.428, Inf)
  }else if(i == 4){
    breaks = c(-Inf,43.8,120,162,224,254,Inf)
  }
  else if(i == 5){
    breaks = c(-Inf,2.78e+03,4.5e+03,5.98e+03,7.99e+03,1e+04,1.25e+04,1.56e+04,2.06e+04,3.31e+04,Inf)
  }else if(i == 6){
    breaks = c(-Inf,0.09189,0.2594,0.5058,0.7491,1.003,1.235,Inf)
  }else if(i == 7){
    breaks = c(-Inf,-0.124,0.00674,0.00747,0.00814,0.00921,0.0336,0.366,Inf)
  }else if(i == 8){
    breaks = c(-Inf,2,3,4,5,12,19,34,Inf)
  }else if(i == 9){
    breaks = c(-Inf,-90,0,31.2,287,Inf)
  }else if(i == 10){
    breaks = c(0,0.0879,0.25,0.43,3.09,Inf)
  }else if(i == 11){
    breaks = c(-Inf,0.5,0.836,1.71,2,2.5,3.5,Inf)
  }else if(i == 12){
    breaks = c(0,45,61,73,Inf)
  }else if(i == 13){
    breaks = c(0,127,1.57e+03,1.14e+04,3.11e+04,Inf)
  }else if(i == 14){
    breaks = c(0,1.68e+04,Inf)
  }else if(i == 15){
    breaks = c(0,50,5.12e+03,1.02e+04,2e+04,3e+04,5e+04,9.52e+04,Inf)
  }
  
  
  x_levels = cut(x, breaks, right=FALSE, labels=1:(length(breaks)-1))
  if(i == 2){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[9,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[1,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[2,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[3,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[4,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[5,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[6,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[7,7]}
      else if(x_levels[j]==8){
        khls_woe_2018_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[8,7]}
      
    }
    
  }
  if(i == 3){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[16,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[10,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[11,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[12,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[13,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[14,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[15,7]}
      
    }
    
  }
  
  if(i == 4){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[23,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[17,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[18,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[19,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[20,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[21,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[22,7]}
      
    }
    
  }
  if(i == 5){
    for(j in 1:68859){
      if(x_levels[j]==10){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[33,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[24,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[25,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[26,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[27,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[28,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[29,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[30,7]}
      else if(x_levels[j]==8){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[31,7]}
      else if(x_levels[j]==9){
        khls_woe_2018_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[32,7]}
      
    }
    
  }
  if(i == 6){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[41,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[34,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[35,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[36,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[37,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[38,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[39,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[40,7]}
    }
    
  }
  
  if(i == 7){
    for(j in 1:68859){
      if(x_levels[j]==8){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[49,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[42,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[43,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[44,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[45,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[46,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[47,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[48,7]}
      
    }
    
  }
  if(i == 8){
    for(j in 1:68859){
      if(x_levels[j]==8){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[57,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[50,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[51,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[52,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[53,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[54,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[55,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[56,7]}
      
    }
    
  }
  if(i == 9){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[63,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[58,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[59,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[60,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[61,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[62,7]}
    }
    
  }
  if(i == 10){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[69,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[64,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[65,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[66,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[67,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[68,7]}
    }
    
  }
  if(i == 11){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[77,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[70,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[71,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[72,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[73,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[74,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[75,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[76,7]}
    }
    
  }
  if(i == 12){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[82,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[78,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[79,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[80,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[81,7]}
    }
    
  }
  if(i == 13){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[88,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[83,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[84,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[85,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[86,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[87,7]}
    }
    
  }
  if(i == 14){
    for(j in 1:68859){
      if(is.na(x_levels[j])){
        khls_woe_2018_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[91,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[89,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[90,7]}
      
    }
    
  }
  if(i == 15){
    for(j in 1:68859){
      if(x_levels[j]==8){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[99,7]
      }else if(x_levels[j]==1){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[92,7]
      }else if(x_levels[j]==2){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[93,7]}
      else if(x_levels[j]==3){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[94,7]}
      else if(x_levels[j]==4){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[95,7]}
      else if(x_levels[j]==5){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[96,7]}
      else if(x_levels[j]==6){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[97,7]}
      else if(x_levels[j]==7){
        khls_woe_2018_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[98,7]}
      
    }
  }
}
#ȫ����ģ��Ԥ��
pre5_316 = predict(fit1_5_17,type="response",newdata= khls_woe_2018_all_316)
#modelroc5_01 = roc(khls_use_now$ls,pre5_316)
#plot(modelroc5_01,print.auc=TRUE,auc.polygon=TRUE,grid=c(0.1,0.2),grid.col=c("green","red"),max.auc.polygon=TRUE,auc.polygon.col="brown",print.thres=TRUE)
pred03 <- prediction(predictions=pre5_316,labels=khls_use_now$ls)
perf03 <- performance(pred03,measure="tpr",x.measure="fpr")
plot(perf03,main="�ͻ���ʧԤ��ģ��ȫ������ROC����",
     col="blue",lwd=3)
abline(a=0,b=1,lwd=2,lty=2)
perf_auc03 <- performance(pred03,measure="auc")
unlist(perf_auc03@y.values)

#ȫ����ģ��ʹ�ý���
write.csv(pre5_316,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre5_3_16.csv')
pre5_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre5_3_16.csv')
pre5_ls04 = data.frame(ls_rate = pre5_new$x,ls_flag = khls_use_now$ls)
pre5_levels = cut(pre5_ls04$ls_rate, breaks01, right=FALSE, labels=1:(length(breaks01)-1))
levs05 = levels(cut(pre5_ls04$ls_rate, breaks01, right=FALSE))
model_use_3_16_all = data.frame(ls_rate = pre5_ls04$ls_rate, ls_flag = pre5_ls04$ls_flag,label = pre5_levels,space = rep(NA,68859))
for(i in 1:68859){
  for(j in 1:20){
    if(is.na(model_use_3_16_all[i,3])){
      model_use_3_16_all[i,'space'] = model_use_3_16_all[i,'ls_rate']
    }
    else if(model_use_3_16_all[i,3]==j){
      model_use_3_16_all[i,'space'] = levs05[j]
    }
  }
  
}
write.csv(model_use_3_16_all,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_3_16_all.csv')
model_use_all_3_16 = data.frame(avg_score = rep(NA,20),max_score = rep(NA,20),min_score =rep(NA,20),bad=rep(NA,20),good = rep(NA,20))
avg_score = aggregate(model_use_3_16_all$ls_rate~model_use_3_16_all$label, data=model_use_3_16_all, FUN="mean")
max_score = aggregate(model_use_3_16_all$ls_rate~model_use_3_16_all$label,data = model_use_3_16_all,FUN = "max")
min_score = aggregate(model_use_3_16_all$ls_rate~model_use_3_16_all$label,data = model_use_3_16_all,FUN = "min")
total_count = aggregate(model_use_3_16_all$ls_flag~model_use_3_16_all$label,data = model_use_3_16_all,FUN = "length")
bad_count = aggregate(model_use_3_16_all$ls_flag~model_use_3_16_all$label,data = model_use_3_16_all,FUN = "sum")

model_use_all_3_16 = data.frame(avg_score03 = avg_score[,2],max_score03 = max_score[,2],
                                min_score03 = min_score[,2],total_count03 = total_count[,2],
                                bad_count03 = bad_count[,2])

write.csv(model_use_all_3_16,'//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_all_3_16.csv')

#������ɫ������ȫ��������
khls_woe_hey_all_316 = data.frame(last_twelve_fund_inflow_woe = rep(NA,84968),last_three_month_collect_ratio_woe=rep(NA,84968),
                                  last_twelve_month_avg_join_inter_woe = rep(NA,84968),avg_last_twelve_tender_money_woe = rep(NA,84968),
                                  last_one_ratio_avg_twelve_woe = rep(NA,84968),last_one_month_asset_ratio_woe = rep(NA,84968),
                                  last_twelve_tender_times_woe = rep(NA,84968),last_one_month_use_change_woe = rep(NA,84968),
                                  last_one_month_award_money_woe = rep(NA,84968),last_twelve_t_tender_to_repay_woe = rep(NA,84968),
                                  last_three_tixian_inter_woe = rep(NA,84968),last_one_hk_money_woe = rep(NA,84968),
                                  last_one_suc_rec_money_woe = rep(NA,84968),last_three_tender_money_woe = rep(NA,84968))

khls_all_sample_hey = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/khls_all_sample_hey.csv')
for(i in 2:n_var03){
  x=khls_all_sample_hey[,var_names08[i]]
  if(i == 2){
    breaks = c(-Inf,-1.69e+04,7.27e+03,1.21e+04,1.98e+04,3e+04,4.91e+04,1.4e+05,Inf)
  }
  else if(i == 3){
    breaks = c(-Inf,-0.816,-0.302,0.0344,0.157,0.428, Inf)
  }else if(i == 4){
    breaks = c(-Inf,43.8,120,162,224,254,Inf)
  }
  else if(i == 5){
    breaks = c(-Inf,2.78e+03,4.5e+03,5.98e+03,7.99e+03,1e+04,1.25e+04,1.56e+04,2.06e+04,3.31e+04,Inf)
  }else if(i == 6){
    breaks = c(-Inf,0.09189,0.2594,0.5058,0.7491,1.003,1.235,Inf)
  }else if(i == 7){
    breaks = c(-Inf,-0.124,0.00674,0.00747,0.00814,0.00921,0.0336,0.366,Inf)
  }else if(i == 8){
    breaks = c(-Inf,2,3,4,5,12,19,34,Inf)
  }else if(i == 9){
    breaks = c(-Inf,-90,0,31.2,287,Inf)
  }else if(i == 10){
    breaks = c(0,0.0879,0.25,0.43,3.09,Inf)
  }else if(i == 11){
    breaks = c(-Inf,0.5,0.836,1.71,2,2.5,3.5,Inf)
  }else if(i == 12){
    breaks = c(0,45,61,73,Inf)
  }else if(i == 13){
    breaks = c(0,127,1.57e+03,1.14e+04,3.11e+04,Inf)
  }else if(i == 14){
    breaks = c(0,1.68e+04,Inf)
  }else if(i == 15){
    breaks = c(0,50,5.12e+03,1.02e+04,2e+04,3e+04,5e+04,9.52e+04,Inf)
  }
  
  
  x_levels = cut(x, breaks, right=FALSE, labels=1:(length(breaks)-1))
  if(i == 2){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[9,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[1,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[2,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[3,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[4,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[5,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[6,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[7,7]}
      else if(x_levels[j]==8){
        khls_woe_hey_all_316[j,'last_twelve_fund_inflow_woe'] = khls_levels2018_04_new01[8,7]}
      
    }
    
  }
  if(i == 3){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[16,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[10,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[11,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[12,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[13,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[14,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_three_month_collect_ratio_woe'] = khls_levels2018_04_new01[15,7]}
      
    }
    
  }
  
  if(i == 4){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[23,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[17,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[18,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[19,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[20,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[21,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_twelve_month_avg_join_inter_woe'] = khls_levels2018_04_new01[22,7]}
      
    }
    
  }
  if(i == 5){
    for(j in 1:84968){
      if(x_levels[j]==10){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[33,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[24,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[25,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[26,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[27,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[28,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[29,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[30,7]}
      else if(x_levels[j]==8){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[31,7]}
      else if(x_levels[j]==9){
        khls_woe_hey_all_316[j,'avg_last_twelve_tender_money_woe'] = khls_levels2018_04_new01[32,7]}
      
    }
    
  }
  if(i == 6){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[41,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[34,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[35,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[36,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[37,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[38,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[39,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_one_ratio_avg_twelve_woe'] = khls_levels2018_04_new01[40,7]}
    }
    
  }
  
  if(i == 7){
    for(j in 1:84968){
      if(x_levels[j]==8){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[49,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[42,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[43,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[44,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[45,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[46,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[47,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_one_month_asset_ratio_woe'] = khls_levels2018_04_new01[48,7]}
      
    }
    
  }
  if(i == 8){
    for(j in 1:84968){
      if(x_levels[j]==8){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[57,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[50,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[51,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[52,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[53,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[54,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[55,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_twelve_tender_times_woe'] = khls_levels2018_04_new01[56,7]}
      
    }
    
  }
  if(i == 9){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[63,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[58,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[59,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[60,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[61,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_one_month_use_change_woe'] = khls_levels2018_04_new01[62,7]}
    }
    
  }
  if(i == 10){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[69,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[64,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[65,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[66,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[67,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_one_month_award_money_woe'] = khls_levels2018_04_new01[68,7]}
    }
    
  }
  if(i == 11){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[77,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[70,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[71,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[72,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[73,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[74,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[75,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_twelve_t_tender_to_repay_woe'] = khls_levels2018_04_new01[76,7]}
    }
    
  }
  if(i == 12){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[82,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[78,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[79,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[80,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_three_tixian_inter_woe'] = khls_levels2018_04_new01[81,7]}
    }
    
  }
  if(i == 13){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[88,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[83,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[84,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[85,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[86,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_one_hk_money_woe'] = khls_levels2018_04_new01[87,7]}
    }
    
  }
  if(i == 14){
    for(j in 1:84968){
      if(is.na(x_levels[j])){
        khls_woe_hey_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[91,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[89,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_one_suc_rec_money_woe'] = khls_levels2018_04_new01[90,7]}
      
    }
    
  }
  if(i == 15){
    for(j in 1:84968){
      if(x_levels[j]==8){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[99,7]
      }else if(x_levels[j]==1){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[92,7]
      }else if(x_levels[j]==2){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[93,7]}
      else if(x_levels[j]==3){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[94,7]}
      else if(x_levels[j]==4){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[95,7]}
      else if(x_levels[j]==5){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[96,7]}
      else if(x_levels[j]==6){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[97,7]}
      else if(x_levels[j]==7){
        khls_woe_hey_all_316[j,'last_three_tender_money_woe'] = khls_levels2018_04_new01[98,7]}
      
    }
  }
}

pre6_01 = predict(fit1_5_17,type="response",newdata= khls_woe_hey_all_316)

#ȫ������������ɫ������ģ��ʹ�ý��飩
write.csv(pre6_01,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre6_03_16.csv')
pre6_new = read.csv('//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/pre6_03_16.csv')
pre6_ls05 = data.frame(ls_rate = pre6_new$x,ls_flag = khls_all_sample_hey$ls)

pre6_levels = cut(pre6_ls05$ls_rate, breaks01, right=FALSE, labels=1:(length(breaks01)-1))
levs06 = levels(cut(pre6_ls05$ls_rate, breaks01, right=FALSE))
model_use_3_16_hey = data.frame(ls_rate = pre6_ls05$ls_rate, ls_flag = pre6_ls05$ls_flag,label = pre6_levels,space = rep(NA,84968))
for(i in 1:84968){
  for(j in 1:20){
    if(is.na(model_use_3_16_hey[i,3])){
      model_use_3_16_hey[i,'space'] = model_use_3_16_hey[i,'ls_rate']
    }
    else if(model_use_3_16_hey[i,3]==j){
      model_use_3_16_hey[i,'space'] = levs06[j]
    }
  }
  
}
write.csv(model_use_3_16_hey,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_3_16_hey.csv')
model_use_all_new_3_16 = data.frame(avg_score = rep(NA,20),max_score = rep(NA,20),min_score =rep(NA,20),bad=rep(NA,20),good = rep(NA,20))
avg_score = aggregate(model_use_3_16_hey$ls_rate~model_use_3_16_hey$label, data=model_use_3_16_hey, FUN="mean")
max_score = aggregate(model_use_3_16_hey$ls_rate~model_use_3_16_hey$label,data = model_use_3_16_hey,FUN = "max")
min_score = aggregate(model_use_3_16_hey$ls_rate~model_use_3_16_hey$label,data = model_use_3_16_hey,FUN = "min")
total_count = aggregate(model_use_3_16_hey$ls_flag~model_use_3_16_hey$label,data = model_use_3_16_hey,FUN = "length")
bad_count = aggregate(model_use_3_16_hey$ls_flag~model_use_3_16_hey$label,data = model_use_3_16_hey,FUN = "sum")

model_use_all_new_3_16 = data.frame(avg_score04 = avg_score[,2],max_score04 = max_score[,2],
                                    min_score04 = min_score[,2],total_count04 = total_count[,2],
                                    bad_count04 = bad_count[,2])

write.csv(model_use_all_new_3_16,'//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/model_use_all_new_3_16.csv')

#��ȡģ�ͽ��
summary(fit1_new01_new)
write.csv(summary(fit1_new01_new)$coefficients,file = '//10.0.3.98/��ģ����/DJW/�ͻ���ʧԤ����Ŀ/data/fit1_new01_new.csv')


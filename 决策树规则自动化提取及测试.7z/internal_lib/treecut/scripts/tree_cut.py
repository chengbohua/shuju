# -*- coding: utf-8 -*-
"""
Created on Sun Jun  9 21:06:16 2019

@author: D_HE
"""

from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import pandas as pd
import numpy as np
import re


def tree_split(df,col,target='y',max_groups=6,special_points=[]):
    '''
    参数：
        df：数据集；
        col：需要切分的变量名；
        target：目标变量名；
        max_groups：最大箱数；
        special_point：需要单独分组的特殊值点，空值不需要设置；
    return:
        切分点，升序    
    '''
    df_t = df[df[col].notnull()]
    df_t = df_t[~df_t.isin(special_points)]
    X = df_t[[col]]
    y = df_t[target]
    try:
        dtc = DecisionTreeClassifier(max_leaf_nodes=max_groups,
                                     min_samples_leaf=int(len(df_t)*0.05))
        dtc.fit(X,y)
    except:
        dtc = DecisionTreeClassifier(max_leaf_nodes=max_groups,
                                     min_samples_leaf=1)
        dtc.fit(X,y)
    
    dot_data=tree.export_graphviz(dtc,out_file=None,
                                  feature_names=[col],
                                  class_names=['0','1'],filled=True)
    splits_t=re.findall(r' <= (.*?)\\n',dot_data)
    splits = [float(x) for x in splits_t]
    return sorted(splits)


def AssignGroup(x, bins, special_points=[]):
    '''
    参数：
        x: 一个变量的取值
        bins: 变量的切分点
    返回：
        该取值所处范围的上界,异常值点和空值单独返回，空返回-998
    '''
    if x in special_points:
        return x
    elif pd.isnull(x)==True:        
        return -998
    else:
        try:
            N = len(bins)
            if x<=min(bins):
                return min(bins)
            elif x>max(bins):
                return 1e21
            else:
                for i in range(N-1):
                    if bins[i] < x <= bins[i+1]:
                        return bins[i+1]
        except:
            return x
        
  

def preWOE(df, col, target, max_groups=6, split=[], special_points=[]):
    '''
    查看分组的WOE与IV
    参数：
        df：数据集
        col：需要查看的变量
        target：目标变量
        split：切分点
    返回：
        该变量各分组的WOE与IV
    '''
    tdata = df[[col,target]].copy()
    if tdata[col].dtype=='O':
        tdata['temp'] = tdata[col].fillna(-998)
    else:
        if split==[]:
            split = tree_split(tdata,col,target,max_groups=max_groups,special_points=special_points)  
        try:
            tdata['temp'] = tdata[col].map(lambda x: AssignGroup(x, split,special_points))
        except:
            tdata['temp'] = tdata[col]
    
    #分箱后的好坏客户数
    temp_tab = pd.crosstab(tdata['temp'], tdata[target],margins=True)
    if 1 not in temp_tab.columns:
        temp_tab[1] = [0,0,0]
    temp_tab['bad_rate'] = temp_tab[1]/temp_tab['All']
    temp_tab['woe'] = np.log(temp_tab[0]/temp_tab[1])-np.log(temp_tab.ix['All',0]/temp_tab.ix['All',1])
    temp_tab['IV'] = (temp_tab[0]/temp_tab.ix['All',0]-\
            temp_tab[1]/temp_tab.ix['All',1])*temp_tab['woe']
    temp_tab['IV'] = temp_tab['IV'].replace(np.inf,0)
    temp_tab.ix['All','IV'] = temp_tab['IV'].iloc[:-1].sum()
    #woe和IV仅保留四位有效数字
    temp_tab[['bad_rate','woe','IV']] = temp_tab[['bad_rate','woe','IV']].apply(lambda x:round(x,4))
    temp_tab.index.name='woe_'+col
    return temp_tab,split


def WOE(df, col, target, max_groups=6, split=[], special_points=[]):
    '''
    WOE编码
    参数：
        df：数据集
        col：需要编码的变量
        target：目标变量
        split：切分点
    返回：
        WOE编码后的数据集，编码后的字段名为woe_原始变量名;
        变量的iv值
    ''' 
    temp_ = preWOE(df, col, target, max_groups, split, special_points)
    temp_woe = temp_[0]
    split = temp_[1]
    woe_dict = dict(zip(temp_woe.index,temp_woe.woe))    
    try:
        df['woe_'+col] = df[col].map(lambda x: AssignGroup(x, split))
    except:
        df['woe_'+col] = df[col]
    df['woe_'+col] = df['woe_'+col].map(lambda x: woe_dict[x])
    iv = temp_woe.ix['All','IV']
    print(temp_woe)
    return woe_dict,iv,temp_woe,split

def woe_show(df,col_list,path,file_name,label='放款年月',max_groups=6,target='y'):
    '''
    参数：
        df：包含X和y的数据集；
        target：目标变量名;
        path：结果写入地址；
        col_list：需要查看的变量列表，数值型变量；
        max_groups：最大分箱数；   
        label：分月查看字段名，默认为放款年月
    返回：
        写入本地的woe详细结果；
        返回woe转换列表
    '''
    
    ivs = pd.DataFrame(columns=['变量名','IV','woe_dict'])
    woe_res = {}
    monthly_res0={}
    monthly_res1={}
    monthly_res2={}
    for col in col_list:
        print(col)
        temp_res = WOE(df, col, target, max_groups, split=[], special_points=[])
        woe_res[col] = temp_res[2]
        ivs = ivs.append(pd.DataFrame([[col,temp_res[1],temp_res[0]]],
                                    columns=['变量名','IV','woe_dict']))
        ivs.sort_values(['IV'],ascending=False,inplace=True)
        ivs.index = range(1,len(ivs)+1)
    
        '''分月数据查看'''
        tdata = df[[col,target,label]]
        if df[col].dtype=='O':
            tdata['temp'] = tdata[col].fillna(-998)
        try:
            tdata['temp'] = tdata[col].map(lambda x: AssignGroup(x, temp_res[3]))
        except:
            tdata['temp'] = tdata[col] 
        #分月占比
        temp_res0 = tdata[target].groupby([tdata['temp'],tdata[label]]).count().unstack()
        temp_res0.ix['All',:] = tdata[target].groupby(tdata[label]).count()
        temp_res0 = temp_res0/temp_res0.ix['All',:]
        temp_res0 = temp_res0.apply(lambda x: round(x,3))
        temp_res0['woe'] = woe_res[col]['woe']
        temp_res0.index.name='占比'+col
        #分月坏账率
        temp_res1 = tdata[target].groupby([tdata['temp'],tdata[label]]).mean().unstack()
        temp_res1.ix['All',:] = tdata[target].groupby(tdata[label]).mean()
        temp_res1 = temp_res1.apply(lambda x: round(x,3))
        temp_res1['woe'] = woe_res[col]['woe']
        temp_res1.index.name='坏账率'+col
        #分月提升度
        temp_temp = temp_res1.drop(columns=['woe'])         
        temp_res2 = temp_temp.copy()/temp_temp.ix['All',:].copy()
        temp_res2 = temp_res2.apply(lambda x: round(x,3))
        temp_res2['woe'] = woe_res[col]['woe']
        temp_res2.index.name='提升度'+col
        
        temp_res0 = temp_res0.ix[woe_res[col].index.tolist()]
        temp_res1 = temp_res1.ix[woe_res[col].index.tolist()]
        temp_res2 = temp_res2.ix[woe_res[col].index.tolist()]        
        
        monthly_res0[col] = temp_res0
        monthly_res1[col] = temp_res1
        monthly_res2[col] = temp_res2       
    
    writer = pd.ExcelWriter(path+file_name)
    startrows=0
    for i in ivs['变量名']:
        woe_res[i].to_excel(writer,startrow=startrows,sheet_name='WOE详细')
        start_flag1 = woe_res[i].shape[1]+2
        monthly_res0[i].to_excel(writer,startrow=startrows,startcol=start_flag1,sheet_name='WOE详细')
        start_flag2 = start_flag1+monthly_res0[i].shape[1]+2
        monthly_res2[i].to_excel(writer,startrow=startrows,startcol=start_flag2,sheet_name='WOE详细')
        start_flag3 = start_flag2+monthly_res2[i].shape[1]+2
        monthly_res1[i].to_excel(writer,startrow=startrows,startcol=start_flag3,sheet_name='WOE详细')
        startrows+=len(woe_res[i])+3
    ivs.to_excel(writer,sheet_name='IV总览')
    writer.save()
    writer.close()
    return ivs

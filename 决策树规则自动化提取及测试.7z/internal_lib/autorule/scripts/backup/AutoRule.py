# -*- coding: utf-8 -*-
"""
Created on Fri Sep 14 13:47:18 2018

@author: wj61032
"""
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import pandas as pd
import graphviz,os
import numpy as np
import re
os.environ["PATH"] += os.pathsep + 'C:/Program Files (x86)/Graphviz2.38/bin'

def auto_rule(X,y,to_path,param_,standard,random_num=66,pre_process=1):
    '''
    params:
        X-必选参数，自变量，数据类型为DataFrame
        y-必选参数，因变量，数据类型为Series
        to_path-必选参数，结果输出的位置
        param_-必选参数，调整决策树的参数
        standard-必选参数，设置规则筛选标准
        
        random_num-可选参数，随机数种子,默认为66,
                   不同的种子会获得不同的训练集及测试集，
                   最终获取的规则也不同，若未能获得满意的规则，可尝试调节
                   随机数种子来改变训练集和测试集的样本，重新提取规则
        pre_process-可选参数，是否进行预处理，默认为1进行预处理,
                   默认将字符型变量OneHot编码，将缺失值填充-99,
                   但仍建议字符型变量的处理以及缺失值的填充在函数调用前完成,
                   若没有字符型变量以及缺失值,则预处理不会改变数据结构,
                   即便如此,仍然提供pre_process!=1以关闭该功能。
                   
        
    returns:
        return0-返回所有满足规则筛选标准的规则，规则代码，规则表现(训练集，测试集，全集)
                若父节点和子节点均符合规则，则两条规则均会返回，规则间存在包含关系
        return1-返回所有满足规则筛选标准的父节点规则，规则代码，规则表现(训练集，测试集，全集)
                若父节点和子节点均符合规则，则仅返回父节点对应的规则，该返回中所有规则间不交叉
        return2-当前决策树的变量重要性，降序排列
        return3-可视化的决策树
        X_train,
        y_train,
        X_test,
        y_test
    
    注:
        返回值return0-return3均会保存至位置-path
    ===============================================================================
    '''
    
    '''
    数据预处理,训练集，测试集的划分
    -------------------------------------------------------------------------------
    '''
    print('变量类型:\n{}'.format(X.dtypes.value_counts()))
    print('-'*50)
    
    if pre_process==1:
        X = pd.get_dummies(X,dummy_na=True) 
        X.fillna(-99,inplace=True)
        X.columns = [x.replace(' ','').replace(':','') for x in X.columns]
        
    X_train,X_test,y_train,y_test = train_test_split(X,y,
                                                     test_size=0.3,
                                                     random_state=random_num,
                                                     stratify=y)
    
    '''
    训练集决策树的生成
    -------------------------------------------------------------------------------
    '''
    param_.update({'random_state':random_num})
    dtc = DecisionTreeClassifier(**param_) 
    dtc.fit(X_train,y_train)
    dot_data=tree.export_graphviz(dtc,out_file=None,
                                  feature_names=list(X_train.columns),
                                  class_names=['0','1'],filled=True)
    graph = graphviz.Source(dot_data)
#    graph.render(to_path+'决策树')
    
    # 决策树变量重要性，降序
    imp = pd.DataFrame();imp['变量'] = X_train.columns;imp['重要性']=dtc.feature_importances_   
    imp.sort_values('重要性',ascending=False,inplace=True)
    imp.index=range(1,len(imp)+1)
    
    '''
    dot文件解析，决策树规则提取
    ===============================================================================
    '''
    test = pd.DataFrame(dot_data.split(';'),columns=['dot原文'])
    test['dot原文'] = test['dot原文'].str.replace('\n','&')
    test['flag'] = test['dot原文'].apply(lambda x: ('->' in x))
    test0=test[test['flag']==True]
    '''各节点坏账率'''
    test1=test[test['flag']==False]
    test1=test1.iloc[1:-1,:]
    test1['节点'] = test1['dot原文'].apply(lambda x: int(re.findall('&(.*?) ',x)[0]))
    test1['0_1'] = test1['dot原文'].apply(lambda x: re.findall('= \[(.*?),(.*?)\]',x))
    test1['节点内容'] = test1['dot原文'].apply(lambda x: re.findall('label="(.*?)gini',x)[0].replace('\\n',''))
    test1['好客户数'] = test1['0_1'].apply(lambda x: int(x[0][0]))
    test1['坏客户数'] = test1['0_1'].apply(lambda x: int(x[0][1]))
    test1['客户总数'] = test1['好客户数']+test1['坏客户数']
    test1['坏客户比率'] = test1['坏客户数']/test1['客户总数']
    tol_num = (test1['客户总数'][test1['节点']==0]).values[0]
    bad_num = (test1['坏客户数'][test1['节点']==0]).values[0]
    test1['提升度'] = (test1['坏客户数']/bad_num)/(test1['客户总数']/tol_num)
    test1 = test1[['节点','节点内容','好客户数','坏客户数','客户总数','坏客户比率','提升度']].sort_values(['提升度'],ascending=False)
    
    '''各节点到达途径'''
    test0['节点路径'] = test0['dot原文'].apply(lambda x: re.findall('&(.*?->.*?\d) ',x)[0])
    test0['起点'] = test0['节点路径'].apply(lambda x: int(x.split(' -> ')[0]))
    test0['终点'] = test0['节点路径'].apply(lambda x: int(x.split(' -> ')[1]))
    test0['序号'] = range(len(test0))
    def left_or_right(x):
        '''获取左右节点信息'''
        num = test0['序号'][test0['终点']==x].values[0]+1
        start = test0['起点'][test0['终点']==x].values[0]
        temp = test0['起点'].iloc[:num,]
        if (temp==start).value_counts()[True]==2:
            return '右节点'
        else:
            return '左节点'
    
    def path(x,tol_pt):    
        pt = test0['节点路径'][test0['终点']==x].values[0]
        start = test0['起点'][test0['终点']==x].values[0]
        tol_pt.append(pt)
        if start!=0:
            path(start,tol_pt)
            
    def tot_path(x):
        '''获取到达节点的完整路径'''
        tol_pt=[]
        path(x,tol_pt)
        return tol_pt[::-1]
    
    def path_real(x):
        '''生成路径对应的规则以及规则对应的Python代码'''
        result=''
        result1=''
        for i in x:
            i_temp=i.split(' -> ')
            i0 = int(i_temp[0])
            i2 = i_temp[2]
            cont = test1['节点内容'][test1['节点']==i0].values[0]
            if i2=='右节点':
                cont=cont.replace('<=','>')
            result=result+'('+cont.replace(' ','')+')&'
            result1=result1+"(df['"+cont.replace(' ','')+')&'
        result1 = 'np.where({},1,0)'.format(result1[:-1])
        result1=result1.replace('<',"']<")
        result1=result1.replace('>',"']>")
        return result[:-1], result1
    
    test0['左右节点'] = test0['终点'].apply(left_or_right)
    test0['节点路径'] = test0['节点路径']+' -> '+test0['左右节点']
    test0 = test0[['节点路径', '起点', '终点', '左右节点']]
    test0['完整路径'] =test0['终点'].apply(lambda x: tot_path(x))
    test0['真实路径'] = test0['完整路径'].apply(lambda x: path_real(x)[0])
    test0['规则代码'] = test0['完整路径'].apply(lambda x: path_real(x)[1])
    
    '''规则结果'''
    result = pd.merge(test0,test1,left_on='终点',right_on='节点',how='left')     
    result.sort_values('提升度',ascending=False,inplace=True)
    result['真实路径'] = result['真实路径'].str.replace('&','且')
    
    '''
    规则的自动化测试
    将规则自动转变为Python代码并在训练集及测试集中测试效果
    ===============================================================================
    '''
    def lift(result):  
        '''提升度的计算'''
        result['7+占比'] = result[1] / result['All']
        result['客户占比'] = result['All'] / result.ix['All','All']
        result['坏客户占总坏客户比例'] = result[1] / result.ix['All',1]
        result['提升度'] = result['坏客户占总坏客户比例']/result['客户占比']
        return result
    
    def tot(rule,x):
        '''训练集，测试集及全集的测试'''
        r1 = rule(X_train,y_train,x).ix[1,:]
        r2 = rule(X_test,y_test,x).ix[1,:]
        r3 = rule(X,y,x).ix[1,:]
        result = pd.DataFrame([r1,r2,r3])
        result.rename(columns={0:'命中好客户',
                               1:'命中坏客户',
                               '7+占比':'坏客户占比'},inplace=True)
        result['数据集'] = ['训练集','测试集','全集']
        return result
    
    def rule(df,ty,x):
        '''规则转Python代码并执行'''
        exec("df['rule']="+x)
        result = pd.crosstab(df['rule'],ty,margins=True)
        if len(result)<3:
            result.ix['All1',:]=result.ix['All',:]
            result.ix[1,:]=[0.1,0,0.1]
            result.index=[0,1,'All']
        result=result.ix[[0,1,'All'],:]
        result=result.fillna(0)
        return lift(result)
    
    '''
    在测试集，训练集中逐条验证所有节点对应的规则
    -------------------------------------------------------------------------------
    '''
    # 输出全部有效规则
    data_out = pd.DataFrame()
    flag=1
    for i in result['规则代码']:    
        rule_ = result['真实路径'][result['规则代码']==i].values[0]
        re_ = tot(rule,i)
        re_['规则']=rule_
        re_['规则代码'] = i
        if standard(re_):
            re_.index=[flag]*3
            flag += 1
            data_out = data_out.append(re_)
    data_out = data_out[['规则','数据集','命中好客户', '命中坏客户', 'All', '坏客户占比', '客户占比', '坏客户占总坏客户比例', '提升度','规则代码']]   
    
    '''子父规则的选取'''
    data_out1 = data_out.copy()
    data_out1['规则复杂度'] = data_out1['规则'].apply(lambda x: len(x.split('且')))
    data_out1.drop_duplicates(['规则'],inplace=True)
    data_out1.sort_values(['规则复杂度'],inplace=True)
    
    rule_list = data_out1['规则'].tolist()
    rule_list0 = data_out1['规则'].tolist()
    for i in rule_list:
        for j in rule_list:
            if (i!=j) and (i in j):
                try:
                    rule_list0.remove(j)
                except:                    
                    pass
                        
    data_outf = data_out[data_out['规则'].isin(rule_list0)]
    inx=range(1,int(data_outf.shape[0]/3)+1)
    inxf=[]
    for i in inx:
        inxf.append(i)
        inxf.append(i)
        inxf.append(i)
    data_outf.index=inxf
    
    '''结果写入本地'''
    writer = pd.ExcelWriter(to_path+'自动化规则结果.xlsx')
    data_out.to_excel(writer,'所有符合要求的规则',encoding='gbk')
    data_outf.to_excel(writer,'所有符合要求的父节点规则',encoding='gbk')
    imp.to_excel(writer,'决策树变量重要性',encoding='gbk')
    rule_list0=data_outf['规则'].drop_duplicates().tolist()
    for j,i in enumerate(rule_list0,start=1):
        temp_list = [x for x in rule_list if i in x]
        temp_dataoutf = pd.DataFrame()
        for rule_num,temp_rule_ in enumerate(temp_list,start=1):            
            temp_dataout = data_out[data_out['规则'].isin([temp_rule_])]
            temp_dataout.index=[rule_num]*3
            temp_dataoutf = temp_dataoutf.append(temp_dataout)
        temp_dataoutf.to_excel(writer,'第'+str(j)+'条父规则对应的所有规则',encoding='gbk')
    writer.save()
    
    return data_out,data_outf,imp,graph,X_train,y_train,X_test,y_test
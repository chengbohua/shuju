# -*- coding: utf-8 -*-
"""
Created on Thu Sep 20 14:47:54 2018

@author: wj61032
"""

import pandas as pd
import numpy as np


def re_rule(data):
    data['TX03']=	np.where(data['gzt_inputxd'] == 2,1,0)
    data['TX04']=	np.where(data['gzt_inputsd'] == 2,1,0)
    data['JX02']=	np.where(data['jxl_dir_black_num'] > 30, 1, 0)
    data['DF01']=	np.where(data['daf_blacklist_is'] == 1, 1, 0)
    data['TH02']=	np.where(data['apct_mult_sps_nm'] >= 1,1,0)
    data['TX02']=	np.where(data['gzt_inputzt'] ==  2,1,0)
    data['FH06']=	np.where(data['zghj_overduecount'] >= 1, 1, 0)
    data['MG05']=	np.where(data['juxl_mg_m6_cnt_cf'] >= 15, 1, 0)
    data['GX08']=	np.where(data['gongxb_zfb_et_avg'] > 500, 1, 0)
    data['B012']=	np.where(data['bair_id_p2p_fraud'] == 0, 1, 0)
    data['MG03']=	np.where(data['juxl_mg_m6_cnt_org'] >= 15, 1, 0)
    #data['JX22']=	np.where(data['juxl_apttelnq_auth'] == '否', 1, 0)
    data['B054']=	np.where(data['bair_cell_p2p_fraud'] == 0, 1, 0)
    data['MG06']=	np.where(data['juxl_mg_cnt_to_black'] > 30, 1, 0)
    data['FH04']=	np.where(data['zghj_generationcount'] >= 2, 1, 0)
    data['ZF02']=	np.where(data['tongfd_orgcount_0_6'] > 7,1,0)
    data['XT36']=	np.where(data['xind_overdue_is'] == 1,1,0)
    data['YX12']=	np.where(data['yix_last6months_num'] > 10,1,0)
    data['ZX06']=	np.where(data['zix_query_6month_num'] > 7,1,0)
    data['XT25']=	np.where(data['xinds_overdue_is'] == 1,1,0)
    data['TH01']=	np.where(data['diff_ap_hv_sm_sps_nm'] >= 1,1,0)
    data['YX04']=	np.where(data['yix_apt_numodm6plus'] >= 1,1,0)
    data['ZF03']=	np.where(data['tongfd_rejected_0_6'] >= 5,1,0)
    data['ZF06']=	np.where(data['tongfd_approved_0_6'] >  6,1,0)
    #data['TX01']=	np.where(data['tianx_idcard_is'] == '不一致',1,0)
    data['ZF01']=	np.where(data['tongfd_black_is'] == '是',1,0)
    data['FH05']=	np.where(data['zghj_generationamount'] >= 500, 1, 0)
    data['GX02']=	np.where(data['gongxb_wx_a_overdueunpay'] > 0, 1, 0)
    data['ZF07']=	np.where(data['tongfd_overduemaxtime'] > 60,1,0)
    data['XT29']=	np.where(data['ck_app_mobileapplgambnum'] >= 2,1,0)
    data['BD03']=	np.where(data['baid_apt_bllevel'].isin(['a', 'b']), 1, 0)
    data['TH03']=	np.where(data['whth_hit_ip_overd_lib']  == 1,1,0)
    data['TH04']=	np.where(data['n5d_ap_ph_in_ot_apct_nm'] >= 1,1,0)
    data['TH08']=	np.where(data['n5d_ap_ph_in_otap_pbk_nm'] >= 1,1,0)
    data['TH14']=	np.where(data['n5d_apct_ph_otap_pbk_nm'] >= 1,1,0)
    data['TH16']=	np.where(data['n5d_apct_ph_otap_ph_nm']  >= 2,1,0)
    data['XT30']=	np.where(data['ck_app_mobileapplloannum'] >= 15,1,0)
    data['ZF09']=	np.where(data['tongfd_overduecleared'] >= 2,1,0)
    data['GX06']=	np.where(data['gongxb_zfb_a_hboverduedays'] > 0, 1, 0)
    data['GX03']=	np.where(data['gongxb_wx_lr_overdue_6_num'] >= 3, 1, 0)
    data['GX04']=	np.where(data['gongxb_wx_lr_overdue_6_num'] >= 3, 1, 0)
    data['GX07']=	np.where(data['gongxb_zfb_a_jiebeiovdable'] == 1, 1, 0)
    data['GX05']=	np.where(data['gongxb_zfb_a_huabeistatus'] == -1, 1, 0)
    data['ZA02']=	np.where(data['zhonga_black_is'] == '是',1,0)
    data['TH09']=	np.where(data['f6_30d_ap_ph_in_otap_pbk_nm'] >= 2,1,0)
    data['TH18']=	np.where(data['n5d_ap_jxl5_as_otap_ph_nm'] >= 2,1,0)
    data['TH10']=	np.where(data['n5d_apct_ph_in_ot_apct_nm'] >= 1,1,0)
    data['XT37']=	np.where(data['apt_ec_currentoverdue'] == 1,1,0)
    data['TH17']=	np.where(data['f6_30d_cntct_ph_otap_ph_nm'] >= 2,1,0)
    data['XT35']=	np.where(data['xinds_loanlongoverday_365'] >= 15,1,0)
    data['TH15']=	np.where(data['f6_30d_apct_ph_otap_pbk_nm'] >= 2,1,0)
    data['XT28']=	np.where(data['ched_blacklist_contactor'] == 1,1,0)
    data['ZX08']=	np.where(data['zix_repay_amount2000_loannum'] >= 1,1,0)
    data['TH12']=	np.where(data['n5d_apct_ph_in_otap_jxl5_nm'] >= 1,1,0)
    data['ZX11']=	np.where(data['zix_repay_12months_5_1_num']  >= 1,1,0)
    data['TH30']=	np.where(data['n5d_otap_jxl5_in_crap_pbk_nm'] >= 1,1,0)
    data['TH19']=	np.where(data['f6_30d_ap_jxl5_as_otap_ph_nm'] >= 2,1,0)
    data['TH20']=	np.where(data['n5d_ap_jxl5_as_ot_apct_ph_nm'] >= 1,1,0)
    data['YX13']=	np.where(data['yix_apt_totalodloanamt'] > 1000,1,0)
    data['TH11']=	np.where(data['f6_30d_apct_ph_in_ot_apct_nm'] >= 1,1,0)
    data['TH22']=	np.where(data['n5d_ap_jxl5_as_otap_jxl5_nm'] >= 1,1,0)
    data['ZX10']=	np.where(data['zix_repay_3months_2_1_num'] >= 1,1,0)
    data['TH05']=	np.where(data['f6_30d_ap_ph_in_ot_apct_nm'] >= 2,1,0)
    data['TH24']=	np.where(data['n5d_ap_jxl5_as_otap_pbk_nm'] >= 1,1,0)
    data['TH06']=	np.where(data['n5d_ap_ph_in_otap_jxl5_nm'] >= 1,1,0)
    data['TH26']=	np.where(data['n5d_otap_ph_in_crap_pbk_nm'] >= 1,1,0)
    data['TH07']=	np.where(data['f6_30d_ap_ph_in_otap_jxl5_nm'] >= 2,1,0)
    data['ST12']=	np.where(data['tongd_final_decision'] == 'reject',1,0)
    data['ST11']=	np.where(data['baiqs_final_decision'] == 'reject',1,0)
    data['VH01']=	np.where(data['apt_ec_usercarloan_is'] == 1,1,0)
    data['ZX13']=	np.where(data['zix_aptpboc_totalodbal'] > 500,1,0)
    data['M005']=	np.where(data['mx_mail_first_overdue_amount_l6m'] >= 3, 1, 0)
    data['M004']=	np.where(data['mx_mail_first_overdue_amount_l3m'] >= 2, 1, 0)
    data['TH29']=	np.where(data['f6_30d_ot_apct_ph_in_crap_pbk_nm'] >= 2,1,0)
    data['TH28']=	np.where(data['n5d_ot_apct_ph_in_crap_pbk_nm']  >= 1,1,0)
    data['TH27']=	np.where(data['f6_30d_otap_ph_in_crap_pbk_nm']  >= 2,1,0)
    data['TH31']=	np.where(data['f6_30d_otap_jxl5_in_crap_pbk_nm'] >= 1,1,0)
    data['TH21']=	np.where(data['f6_30d_ap_jxl5_as_ot_apct_ph_nm'] >= 2,1,0)
    data['TH23']=	np.where(data['f6_30d_ap_jxl5_as_otap_jxl5_nm']  >= 2,1,0)
    data['TH25']=	np.where(data['f6_30d_ap_jxl5_as_otap_pbk_nm']  >= 2,1,0)
    data['ZX04']=	np.where(data['zix_spical_2years_loanfraud_num'] >= 1,1,0)
    data['TH13']=	np.where(data['f6_30d_apct_ph_in_otap_jxl5_nm']  >= 2,1,0)
    data['ZX07']=	np.where(data['zix_repay_amount50000_loannum']  >= 5,1,0)
    data['MG01']=	np.where(data['juxl_mg_blacklist_name_with_phone'] == '是', 1, 0)
    #data['M001']=	np.where(data['mx_base_info_id_card'] !=  data['ck_app_id_lastid'], 1, 0)
    data['M011']=	np.where(data['mx_mail_months_overdue_1_months_l3m'] >= 2, 1, 0)
    data['MG02']=	np.where(data['juxl_mg_blacklist_name_with_idcard'] == '是', 1, 0)
    data['M012']=	np.where(data['mx_mail_months_overdue_1_months_l6m'] >= 2, 1, 0)
    data['M013']=	np.where(data['mx_mail_months_overdue_1_months_l12m'] >= 2, 1, 0)
    data['ZF08']=	np.where(data['tongfd_overdueunclearedamount']  >  500,1,0)
    data['ZX05']=	np.where(data['zix_spical_12months_longarrears_num'] >= 1,1,0)
    data['B133']=	np.where(data['bair_m3_id_nbank_allnum'] >= 15, 1, 0)
    # data['M010']=	np.where(data['mx_user_basic_certificate_number'] !=  data['ck_app_id_lastid'], 1, 0)
    data['ST02']=	np.where((~data['ck_app_nation'].isin(['汉', '满', '土家', '蒙古', '苗'])),1,0)
    data['JX27']=	np.where((data['jxl_eachphone_num']>=0)&(data['jxl_eachphone_num']<=5), 1, 0)
    #data['JX17']=	np.where(data['juxl_apttelnq_nameidcourtblflag'] == '是', 1, 0)
    data['M007']=	np.where((data['mx_sb_tnw_overdue_rate'] >= 0.7)&\
        (data['mx_sb_tnw_overdue_nums'] >= 3),1,0)
    data['JX04']=	np.where((data['jxl_tel_length'] >= 0)& (data['jxl_tel_length'] <6),1,0)
    # data['JX18']=	np.where(data['juxl_apttelnq_nameidfinancialcorpblflag'] == '是', 1, 0)
    data['M008']=	np.where((data['mx_gjj_tnw_overdue_rate'] >= 0.7)&(data['mx_gjj_tnw_success_loan_nums']>=3),1,0)
    # data['JX19']=	np.where(data['juxl_apttelnq_namecellfinancialcorpblflag'] == '是', 1, 0)
    # data['JX15']=	np.where(data['code_jxl1'] != 200, 1, 0)
    data['VC01']=	np.where((data['carcreditd_is'] == 1)&(data['xind_nodrawamount']>0), 1, 0)
    data['ZC01']=	np.where((data['zhongzc_apt_numbl'] >= 1), 1, 0)
    data['YX08']=	np.where((data['yix_lasty1_risksfakenum'] >= 1)|(data['yix_lasty1_riskslosenum'] >= 1), 1, 0)
    data['JX26']=	np.where((data['ck_app_concatnum']<=15)&(data['ck_app_concatnum']>=0)&\
        (data['juxl_apttelnq_l6mnumoutbondcallavg']<=10)&(data['juxl_apttelnq_l6mnumoutbondcallavg']>=0),1,0)
    data['ZA03']=	np.where((data['zhonga_matchrank_home'] == 'mb')|(data['zhonga_matchrank_work'] == 'mb'), 1, 0)
    data['ZX14']=	np.where((data['zix_repay_3months_loannum'] == 0)&(data['zix_query_3month_loan_num'] >= 4), 1, 0)
    
    # 宜信.当前逾期状态出现M1及以上
    #data['YX14']=	np.where(data['yix_overduestatus_array']))  >= 1,1,0)
    data['M009']=	np.where((data['mx_mail_ratio_original_bill_div_all_bills_l6m'] >= 0)&\
        (data['mx_mail_ratio_original_bill_div_all_bills_l6m']) < 1, 1, 0) 
    data['M003']=	np.where((data['mx_mail_total_overdue_amount'] >= 500)&\
        ((data['mx_mail_overdue_flag'].isin([1, 2]))|(data['mx_mail_overdue_status'] == 3)), 1, 0)
    data['ZX03']=	np.where((data['zix_spical_2years_chargedebt_num'] >= 1)|\
        (data['zix_spical_2years_guarantorreturn_num'] >= 1), 1, 0)
    #data['ST16']=	np.where((data['creditda_expscore_totalscore'] < 490)&\
    #    (data['creditda_expscore_totalscore'] > 0)&\
    #    (data['jxl_tel_length'] > 6)&\
    #    (data['jxl_tel_length'] < 14),1,0)
    
    data['ST01']=	np.where(((data['ck_app_age'] >= 0)&\
        (data['ck_app_age'] < 22))|(data['ck_app_age'] > 50), 1, 0)
    
    #data['ST10']=	np.where((data['baiqs_desicion_code'] != 200)&\
    #    (data['tongd_desicion_code'] != 200),1,0)
    #data['TX05']=	np.where((data['zt_inputwfxw'] == 2)&\
    #    (data['gzt_wfxw_casetime'].isin(['[0,0.25)', '[0.25,0.5)', '[0.5,1)', '[1,2)', '[2,5)']),1,0)
    
    data['VC02']=	np.where((data['carcreditd_is'] == 1)&\
        (data['xind_nodrawamount'] <= 0)&\
        (data['xind_loanlongoverday_365'] >= 30), 1, 0)
    data['ST26']=	np.where((data['ck_app_youxau_is'] == 1) &\
        (data['bair_m3_id_nbank_ca_orgnum'] >= 5),1,0)
    
    data['XT41']=	np.where((data['ck_app_concat_apornum'] > 0)&\
        (data['ck_app_concatnum'] > 0)&\
        (data['ck_app_concat_apornum'] >= 0.5*data['ck_app_concatnum']), 1, 0)
    
    
    data['ST25']=	np.where((data['ck_app_youxau_is']==1)&\
        (data['bair_m3_cell_nbank_max_monnum']>=9), 1,0)
    
    data['XT27']=	np.where((data['xind_overdue_is_c'] == 1)&\
        (data['apt_ec_currentoverdue_contactor'] == 1)&\
        (data['xinds_overdue_is_c'] == 1), 1, 0) 
    
    #data['JX25']=	np.where(((data['jxl_id_operator'] == '不匹配')|\
    #    (data['jxl_id_operator'].isnull()))&\
    #    ((data['jxl_name_operator'] == '不匹配')|(data['jxl_name_operator'].isnull())),1,0)
    
    data['TD01']=	np.where((data['td_court_dishonest_perfor_num'] >= 1)|\
        (data['td_court_executing_num'] >= 1),1,0)
    
    data['ST27']=	np.where((data['ck_app_youxau_is'] == 1)&\
        (data['bair_m3_id_nbank_ca_orgnum'] >=5)&\
        (data['ck_app_youxau_is'] < 9),1,0)
    
    
    data['ST39']=	np.where((data['juxl_mg_phone_gray_score'] <= 20)&\
        (data['juxl_mg_phone_gray_score'] >= 9)&\
        (data['jxl_tel_length']  < 12)&\
        (data['jxl_tel_length']  >=0)&\
        (data['yix_lastm3_loanrejnum'] >=1)&\
        (data['yix_lastm3_loanrejnum'] <=4),1,0)
    
    data['BD02']=np.where(data['baid_apt_bltype'].notnull()&\
                        ((data['baid_apt_bltype'].str.find("C03BT004")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C03BT005")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C03BT007")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C03BT008")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C03BT009")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C03BT011")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT012")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT013")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT014")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT015")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT016")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C04BT017")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C05BT018")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C05BT019")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C06BT020")!=-1)|\
                          (data['baid_apt_bltype'].str.find("C06BT022")!=-1)),1,0)
    
    data['ST37']=	np.where(((data['xiaoz_consume_result'].isin(['', '0', 'z']))|\
        (data['xiaoz_consume_result'].isnull()))&\
        (data['bair_educationdegree'].notnull())&\
        (data['juxl_mg_cnt_to_all'] <= 73)&\
        (data['juxl_mg_cnt_to_applied'] > 9)&\
        (data['juxl_mg_searched_org_cnt'] > 6),1,0)
    
    data['ZX09']=	np.where((data['zix_repay_24months_1_2_num'] >=1)|\
        (data['zix_repay_24months_1_3_num'] >=1)|\
        (data['zix_repay_24months_1_4_num'] >=1)|\
        (data['zix_repay_24months_1_5_num'] >=1)|\
        (data['zix_repay_24months_1_6_num'] >=1)|\
        (data['zix_repay_24months_1_7_num'] >=1),1,0)
    
    data['ST21']=	np.where(((data['bair_graduate_code'] !=200)|\
        ((data['bair_graduate_code'] ==200)&(data['bair_educationdegree'].isnull())))&\
        (data['zhonga_agingrank_work'].isin(['X1','X2','X2']))&\
        (data['bair_m3_id_max_monnum']>=7)&\
        (data['ck_app_mobileapplnum']>=57),1,0)
     
    data['ST15']=	np.where((data['baid_apt_bllevel'].isin(['-99', '-9999', 'c', 'd']))&\
        (data['ck_app_concatisnikenum']>=0)&\
        (data['ck_app_concatisnikenum']<=13)&\
        (data['ck_app_mobileapplnum']>=0)&\
        (data['ck_app_mobileapplnum']<=43)&\
        (data['juxl_mg_call_cnt_be_applied']>299)&\
        (data['ck_app_gps_id_area_is'].isnull()),1,0)
    
    data['ST30']=	np.where((data['ck_app_concatjxlallnum']>0)&\
        (data['ck_app_mobileapplnum']>=0)&\
        (data['ck_app_mobileapplnum']<=30)&\
        (data['ck_app_mobileapplloannum']<=3)&\
        (data['baid_apt_bllevel'].isin(['-99', '-9999', 'c', 'd']))&\
        (data['jxl_tel_length']>0)&\
        (data['jxl_tel_length']<39.5),1,0)
    
    data['ST45']=	np.where(((data['ck_app_shebaoau_is']==0)|((data['ck_app_shebaoau_is']==1)&\
        ((data['mx_basic_info_pay_status'].isin(['停缴']))|\
        (data['mx_basic_info_pay_status'].isnull()))))&\
        (data['ck_app_mobileapplnum']<30.5)&(data['juxl_mg_call_cnt_be_black']>=21.5),1, 0)
         
         
    data['ST28']=	np.where((data['ck_app_youxau_is']==1)&\
        (data['bair_m3_id_nbank_ca_orgnum']<5)&\
        (data['bair_m3_cell_nbank_max_monnum']<9)&\
        (data['ck_app_mobileapplnum']<27)&\
        (data['juxl_apttelnq_mcctimeofinbondcall']<123)&\
        (data['baid_apt_bltype'].isnull()),1,0)
    
    data['ST41']=	np.where(((data['zhonga_matchrank_home'].isin(['m0', 'ma']))|(data['zhonga_matchrank_home'].isnull()))&\
        (data['mx_mail_max_months_single_card_succession_bills_l12m']<4)&\
        (data['juxl_mg_weight_to_applied']<78)&\
        (data['xiaoz_consume_result'].isin(['1', '2', '3', '4', '5', '6', '7']))&\
        (data['juxl_apttelnq_numdirectcontact'] < 104)&\
        (data['jxl_tel_loan_call_sumnum']>=11),1,0)
            
    
    data['ST40']=	np.where(((data['zhonga_matchrank_home'].isin(['m0', 'ma']))|(data['zhonga_matchrank_home'].isnull()))&\
        (data['mx_mail_max_months_single_card_succession_bills_l12m']<4)&\
        (data['juxl_mg_weight_to_applied']<78)&\
        (data['jxl_nocturnal_ratio']>0.12)&\
        (data['juxl_apttelnq_mccnumofcell']<57)&\
        (data['xiaoz_consume_result'].isin(['1', '2', '3', '4', '5', '6', '7']))&\
        (data['juxl_apttelnq_numdirectcontact']<104),1,0) 
    return data



#        
#
#data['ST17']=	np.where(data['(    ((      ck_app_node         in   ('ckd_basic_cert', 'ckd_advanced_cert', 'ckd_manual_cert')    and
#    jxl_tel_length       between 6  and 14    and
#    (        ck_app_shebaoau_is ==  '0'      or 
#     (          ck_app_shebaoau_is     ==  '1'        and mx_basic_info_pay_status  in ('停缴', '')        )      )    and
#     
#     (        ck_app_youxau_is  ==  '0'      or
#      (          ck_app_youxau_is        ==  '1'        and mx_mail_max_total_credit_limit <  5000        )      )    and
#      ck_app_gongjijau_is     !=   '1'    and 
#      bair_educationdegree    ==    ''    and 
#      zxt_realestate_verifyresult !=   'y'    ))  and 
#      zhongcx_flight_totalflighttimes <= 0  and 
#      xiaoz_consume_result      in ('', '0', 'z')  ), 1, 0)
#
#data['ST18']=	np.where(data['    (      (        bair_graduate_code   ==  '200'      and
#    bair_educationdegree  ==  ''      )    or bair_graduate_code != '200'    )  and 
#(      ck_app_gps_province_auth  in ('新疆维吾尔自治区', '西藏自治区', '青海省')    or
# (        ck_app_gps_province_auth  in   ('广西壮族自治区')      and 
#  ck_app_gps_city_auth    not in ('南宁市', '桂林市', '柳州市', '')      )    or 
#  (        ck_app_gps_province_auth  in ('福建省', '江苏省', '河南省', '四川省', '云南省', '甘肃省', '贵州省', '山西省', '海南省', '浙江省', '广东省')      and ck_app_gps_city_auth    in ('宁德市', '漳州市', '盐城市', '宿迁市', '驻马店市', '新乡市', '甘孜藏族自治州', '凉山彝族自治州', '绵阳市', '德阳市', '广安市', '楚雄彝族自治州', '红河哈尼族彝族自治州', '文山壮族苗族自治州', '德宏傣族景颇族自治州', '迪庆藏族自治州', '甘南藏族自治州', '阿克塞哈萨克族自治县', '天祝藏族自治县天祝藏族自治县', '积石山保安主动向组萨拉族自治县', '黔东南苗族侗族自治州', '遵义市', '运城市', '海南省', '海口市', '嘉兴市', '湛江市')      )    )  and xiaoz_consume_result  in ('1', '2', '3', '4', '5')  and    (      (        mx_user_basic_corporation_name       in ('', '个人', '个人缴纳', '个人参保')      or mx_fund_basic_corporation_ratio       <= 0      or mx_fund_basic_monthly_corporation_income  <= 0      )    or ck_app_gongjijau_is     != '1'    or mx_payment_allcorpor_months <  6    or mx_fund_basic_pay_status  != 'normal'    or ck_app_id_firstid      != mx_user_basic_certificate_number    or (        mx_user_basic_certificate_number  ==  ''      and (          mx_user_basic_real_name != ck_app_id_lastname        or mx_user_basic_real_name ==  ''        )      )    )    ,  1  ,  0  )  as st18	ST18	1729
#
#data['ST33']=	np.where(data['(    ck_app_youxau_is                    ==  '1'  and xiaoz_consume_result                  in ('', '0', 'z')  and cast(bair_m3_cell_nbank_max_monnum as double)     <  9  and mx_mail_max_months_single_card_succession_bills_l12m  <  4  and ck_app_mobileapplnum                  <  97  and bair_m3_id_nbank_max_inteday              >= 5  and jxl_tel_length                     <  15  and jxl_call_num_aver_6months                <  103  ), 1, 0)  as st33	ST33	599
#data['ST19']=	np.where(data['(    ck_app_shebaoau_is       != '1'  and ck_app_youxau_is        != '1'  and ck_app_gongjijau_is       != '1'  and bair_educationdegree      ==  ''  and zxt_realestate_verifyresult   != 'y'  and zhongcx_flight_totalflighttimes <= 0  and xiaoz_consume_result      in ('', '0', 'z')  and (baiqs_final_decision  rlike  '.*370256.*|.*37026.*|.*369974.*|.*369970.*|.*456859.*|.*456863.*'  or tongd_rules rlike  '.*18612653.*|.*18611803.*|.*18610593.*|.*18614543.*|.*18613703.*|.*18613183.*|.*9274903.*|.*9639613.*')  ), 1, 0)  as st19	ST19	603
#data['ST32']=	np.where(data['(    (      ck_app_youxau_is  ==  '0'    or (        ck_app_youxau_is        ==  '1'      and mx_mail_max_total_credit_limit <  5000      )    )  and ck_app_node             != 'ckd_basic_info'  and jxl_tel_length           <  32.5  and jxl_tel_length           >  0  and yix_apt_numinqcorp         ==  -99  and ck_app_faceregclongesttime     <  22.5  and ck_app_faceregclongesttime     >  0  and juxl_apttelnq_l6mtimeinbondcallavg <  20.5806  and juxl_apttelnq_l6mtimeinbondcallavg >  0  ), 1, 0)  as st32	ST32	643
#data['ST20']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and (      ck_app_youxau_is  ==  '0'    or (        ck_app_youxau_is        ==  '1'      and mx_mail_max_total_credit_limit <  5000      )    )  and ck_app_gongjijau_is       != '1'  and bair_educationdegree      ==  ''  and zxt_realestate_verifyresult   != 'y'  and zhongcx_flight_totalflighttimes <= 0  and xiaoz_consume_result      in ('', '0', 'z')  and juxl_mg_call_cnt_to_applied   >= 255  ), 1, 0)  as st20	ST20	704
#data['ST48']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and ck_app_node           != 'ckd_basic_info'  and ck_app_mobileapplnum      >= 30.5  and ck_app_concatjxlallnum     <  66.5  and (      tongfd_orgcount_6_12  >= 2.5    or tongfd_orgcount_6_12  ==  -99    )  and juxl_apttelnq_timecalllendcorp >= 55  ), 1, 0)  as st48	ST48	526
#data['ST42']=	np.where(data['(    ck_app_youxau_is        ==  '0'  and xiaoz_consume_result      in ('1', '2', '3', '4', '5', '6', '7')  and juxl_apttelnq_numdirectcontact <  119  and juxl_mg_time_spent_to_applied  >= 559  and bair_educationdegree      ==  ''  and ck_app_contact1_rank      >= 10  and ck_app_node           != 'ckd_basic_info'  ), 1, 0)  as st42	ST42	400
#data['ST49']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and ck_app_node       != 'ckd_basic_info'  and ck_app_mobileapplnum  <  30.5  and jxl_tel_length     >= 0  and jxl_tel_length     <  40.5  and ck_app_faceregcalltime >= 22.5  ), 1, 0)  as st49	ST49	429
#data['ST46']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and ck_app_node       != 'ckd_basic_info'  and ck_app_mobileapplnum  <  30.5  and jxl_tel_length     >= 0  and jxl_tel_length     <  40.5  and ck_app_contact1_rank  >= 34.5  ), 1, 0)  as st46	ST46	429
#data['ST31']=	np.where(data['(    (      ck_app_youxau_is  ==  '0'    or (        ck_app_youxau_is        ==  '1'      and mx_mail_max_total_credit_limit <  5000      )    )  and ck_app_node         != 'ckd_basic_info'  and jxl_tel_length       <  32.5  and jxl_tel_length       >  0  and yix_apt_numinqcorp     ==  -99  and ck_app_faceregclongesttime >= 22.5  ), 1, 0)  as st31	ST31	450
#data['ST47']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and ck_app_node         != 'ckd_basic_info'  and ck_app_mobileapplnum    <  30.5  and (      jxl_tel_length ==  -99    or jxl_tel_length >= 40.5    )  and juxl_mg_call_cnt_be_black  >= 21.5  ), 1, 0)  as st47	ST47	453
#data['ST29']=	np.where(data['(    ck_app_youxau_is                ==  '1'  and cast(bair_m3_id_nbank_ca_orgnum as double)   <  5  and cast(bair_m3_cell_nbank_max_monnum as double) <  9  and ck_app_mobileapplnum              >= 102  and juxl_apttelnq_mcctimeofinbondcall        <  123  and juxl_apttelnq_timecalllendcorp         <  58  and cast(bair_m3_id_nbank_max_inteday  as double) <  9  ), 1, 0)  as st29	ST29	462
#data['ST43']=	np.where(data['(    ck_app_youxau_is        ==  '0'  and xiaoz_consume_result      in ('1', '2', '3', '4', '5', '6', '7')  and juxl_apttelnq_numdirectcontact <  119  and juxl_mg_time_spent_to_applied  >= 559  and bair_educationdegree      ==  ''  and ck_app_contact1_rank      <  10  and ck_app_node           != 'ckd_basic_info'  and jxl_tel_length         <  15  and juxl_mg_cnt_to_all       <  38  ), 1, 0)  as st43	ST43	492
#data['ST44']=	np.where(data['(    ck_app_youxau_is        ==  '0'  and xiaoz_consume_result      in ('1', '2', '3', '4', '5', '6', '7')  and juxl_apttelnq_numdirectcontact <  119  and juxl_mg_time_spent_to_applied  >= 559  and bair_educationdegree      ==  ''  and ck_app_contact1_rank      <  10  and ck_app_node           != 'ckd_basic_info'  and jxl_tel_length         >= 15  and ck_app_faceregcalltime     >= 48  ), 1, 0)  as st44	ST44	492
#data['ST35']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and (      ck_app_youxau_is  ==  '0'    or (        ck_app_youxau_is        ==  '1'      and mx_mail_max_total_credit_limit <  5000      )    )  and ck_app_gongjijau_is         != '1'  and bair_educationdegree        ==  ''  and zxt_realestate_verifyresult     != 'y'  and zhongcx_flight_totalflighttimes   <= 0  and xiaoz_consume_result        in ('', '0', 'z')  and juxl_mg_call_cnt_to_applied     <  255  and ck_app_concatnum          <  256  and juxl_apttelnq_mcctimeofinbondcall  <  132  and ck_app_contact1_rank        >= 16  and ck_app_node             != 'ckd_basic_info'  ), 1, 0)  as st35	ST35	944
#data['ST34']=	np.where(data['(    (      ck_app_shebaoau_is ==  '0'    or (        ck_app_shebaoau_is     ==  '1'      and mx_basic_info_pay_status  in ('停缴', '')      )    )  and (      ck_app_youxau_is  ==  '0'    or (        ck_app_youxau_is        ==  '1'      and mx_mail_max_total_credit_limit <  5000      )    )  and ck_app_gongjijau_is         != '1'  and bair_educationdegree        ==  ''  and zxt_realestate_verifyresult     != 'y'  and zhongcx_flight_totalflighttimes   <= 0  and xiaoz_consume_result        in ('', '0', 'z')  and juxl_mg_call_cnt_to_applied     <  255  and juxl_mg_time_spent_to_applied    <  4943  and juxl_apttelnq_mcctimeofinbondcall  <  132  and ck_app_contact1_rank        >= 16  and ck_app_node             != 'ckd_basic_info'  ), 1, 0)  as st34	ST34	945
#
#






